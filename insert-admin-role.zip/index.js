const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Content-Type': 'application/json',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretArn = process.env.DB_SECRET_ARN;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: secretArn
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  console.log('[insert-admin-role] Event:', JSON.stringify(event));

  try {
    const client = await getDbClient();

    // Check if role exists
    const existingCheck = await client.query(
      'SELECT * FROM public.user_roles WHERE user_id = $1',
      ['f6a46bb7-8bcf-413c-a96f-54a05bf30de0']
    );

    console.log('[insert-admin-role] Existing roles:', existingCheck.rows);

    // Always try to insert - using NOT EXISTS pattern
    try {
      await client.query(`
        INSERT INTO public.user_roles (id, user_id, role, assigned_at)
        SELECT gen_random_uuid(), $1::uuid, $2::text::public.app_role, NOW()
        WHERE NOT EXISTS (
          SELECT 1 FROM public.user_roles
          WHERE user_id = $1::uuid
          AND role = $2::text::public.app_role
        )
      `, ['f6a46bb7-8bcf-413c-a96f-54a05bf30de0', 'administrator']);

      console.log('[insert-admin-role] Insert command executed');
    } catch (err) {
      console.log('[insert-admin-role] Insert error:', err.message);
    }

    // Verify
    const finalCheck = await client.query(
      'SELECT * FROM public.user_roles WHERE user_id = $1',
      ['f6a46bb7-8bcf-413c-a96f-54a05bf30de0']
    );

    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        message: 'Admin role verified',
        roles: finalCheck.rows
      })
    };

  } catch (error) {
    console.error('[insert-admin-role] Error:', error);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: error.message })
    };
  }
};
