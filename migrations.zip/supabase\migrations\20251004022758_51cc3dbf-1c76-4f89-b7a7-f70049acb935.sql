-- Add Narrative format to note_format enum
ALTER TYPE note_format ADD VALUE IF NOT EXISTS 'Narrative';