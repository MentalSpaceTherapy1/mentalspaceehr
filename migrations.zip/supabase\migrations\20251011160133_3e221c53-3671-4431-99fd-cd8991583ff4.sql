-- Phase 4: ERA & Payment Posting
-- NOTE: This migration is skipped because these tables were already created in migration
-- 20251010000005_advancedmd_phase4_era_processing.sql with different column names.
-- The tables already exist and are functional.

-- Migration intentionally left empty to maintain migration sequence integrity.
