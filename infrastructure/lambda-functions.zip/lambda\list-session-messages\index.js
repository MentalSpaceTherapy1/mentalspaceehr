/**
 * list-session-messages Lambda Function
 * Fetches chat messages for a telehealth session
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();

    const sessionId = event.pathParameters?.sessionId || event.queryStringParameters?.session_id;
    const limit = parseInt(event.queryStringParameters?.limit || '100');
    const since = event.queryStringParameters?.since; // ISO timestamp for polling

    if (!sessionId) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'session_id is required' })
      };
    }

    let query = `
      SELECT *
      FROM public.session_messages
      WHERE session_id = $1
    `;
    const values = [sessionId];

    // Support polling: only return messages after a certain timestamp
    if (since) {
      query += ` AND created_at > $2`;
      values.push(since);
    }

    query += ` ORDER BY created_at ASC LIMIT $${values.length + 1}`;
    values.push(limit);

    const result = await client.query(query, values);

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify(result.rows)
    };

  } catch (error) {
    console.error('[list-session-messages] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
