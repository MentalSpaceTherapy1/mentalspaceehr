/**
 * create-client Lambda Function
 * Creates a new client record
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  console.log('[create-client] Event:', JSON.stringify(event));

  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const {
      first_name,
      last_name,
      email,
      phone_number,
      date_of_birth,
      gender,
      address_line1,
      city,
      state,
      zip_code,
      primary_therapist_id,
      emergency_contact_name,
      emergency_contact_phone,
      emergency_contact_relationship,
      status = 'active'
    } = body;

    if (!first_name || !last_name) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'First name and last name are required' })
      };
    }

    const client = await getDbClient();

    const result = await client.query(`
      INSERT INTO public.clients (
        first_name, last_name, email, phone_number, date_of_birth,
        gender, address_line1, city, state, zip_code,
        primary_therapist_id, emergency_contact_name, emergency_contact_phone,
        emergency_contact_relationship, status, created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, NOW(), NOW()
      )
      RETURNING *
    `, [
      first_name, last_name, email, phone_number, date_of_birth,
      gender, address_line1, city, state, zip_code,
      primary_therapist_id, emergency_contact_name, emergency_contact_phone,
      emergency_contact_relationship, status
    ]);

    return {
      statusCode: 201,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: result.rows[0] })
    };

  } catch (error) {
    console.error('[create-client] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
