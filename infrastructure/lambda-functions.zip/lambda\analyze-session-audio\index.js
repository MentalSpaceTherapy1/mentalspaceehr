/**
 * analyze-session-audio Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    serve(async (req) => {
      );
      }
    
      try {
        const { audioText, sessionContext, analysisType } = await req.json();
        
        const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
        if (!LOVABLE_API_KEY) {
          throw new Error("LOVABLE_API_KEY is not configured");
        }
    
        let systemPrompt = "";
        let userPrompt = "";
    
        if (analysisType === "sentiment") {
          systemPrompt = "You are a clinical sentiment analyzer. Analyze the emotional tone and provide a sentiment score.";
          userPrompt = `Analyze the sentiment of this session excerpt: "${audioText}"
          
          Context: ${sessionContext || "Telehealth therapy session"}
          
          Respond with a JSON object containing:
          - score: number from -1 (very negative) to 1 (very positive)
          - label: "positive", "neutral", or "negative"
          - confidence: number from 0 to 1
          - reasoning: brief explanation`;
        } else if (analysisType === "transcription") {
          systemPrompt = "You are a medical transcription assistant. Clean and format the transcription.";
          userPrompt = `Clean and format this transcription: "${audioText}"`;
        } else if (analysisType === "insight") {
          systemPrompt = "You are a clinical AI assistant helping therapists during sessions. Provide actionable insights.";
          userPrompt = `Based on this session excerpt: "${audioText}"
          
          Provide a clinical insight as JSON:
          - type: "suggestion", "observation", or "alert"
          - title: brief title
          - content: detailed observation or suggestion
          - confidence: number from 0 to 1`;
        }
    
        const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${LOVABLE_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "google/gemini-2.5-flash",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: userPrompt }
            ],
            temperature: 0.7,
          }),
        });
    
        if (!response.ok) {
          if (response.status === 429) {
            return new Response(
              JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
              { status: 429, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
            );
          }
          if (response.status === 402) {
            return new Response(
              JSON.stringify({ error: "Payment required. Please add credits to your workspace." }),
              { status: 402, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
            );
          }
          
          const errorText = await response.text();
          console.error("AI gateway error:", response.status, errorText);
          throw new Error("AI analysis failed");
        }
    
        const data = await response.json();
        const aiResponse = data.choices[0]?.message?.content;
    
        // Try to parse as JSON first, otherwise return as text
        let result;
        try {
          result = JSON.parse(aiResponse);
        } catch {
          result = { text: aiResponse };
        }
    
        return new Response(
          JSON.stringify(result),
          { headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
        );
    
      } catch (error) {
        console.error("Error in analyze-session-audio:", error);
        return new Response(
          JSON.stringify({ 
            error: error instanceof Error ? error.message : "Unknown error" 
          }),
          { 
            status: 500, 
            headers: { ...CORS_HEADERS, "Content-Type": "application/json" } 
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
