/**
 * list-waiting-room-queue Lambda Function
 * Lists clients waiting for admission by clinician
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();

    const clinicianId = event.queryStringParameters?.clinician_id;

    if (!clinicianId) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'clinician_id is required' })
      };
    }

    // Get waiting clients for clinician's appointments
    const query = `
      SELECT
        wr.*,
        a.start_time as appointment_time,
        a.clinician_id,
        c.first_name as client_first_name,
        c.last_name as client_last_name,
        ts.session_id
      FROM public.telehealth_waiting_rooms wr
      JOIN public.appointments a ON wr.appointment_id = a.id
      JOIN public.clients c ON wr.client_id = c.id
      JOIN public.telehealth_sessions ts ON wr.session_id = ts.session_id
      WHERE a.clinician_id = $1
        AND wr.status = 'Waiting'
        AND wr.timed_out_at IS NULL
      ORDER BY wr.created_at ASC
    `;

    const result = await client.query(query, [clinicianId]);

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify(result.rows)
    };

  } catch (error) {
    console.error('[list-waiting-room-queue] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
