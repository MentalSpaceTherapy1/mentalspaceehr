/**
 * send-portal-invitation Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    const resend = new Resend(process.env.RESEND_API_KEY);
    const supabaseUrl = process.env.SUPABASE_URL!;
    const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
    const siteUrl = process.env.SITE_URL || 'https://98017cf1-a287-4c75-90bf-f5c01f7922ab.lovableproject.com';
    
    interface InvitationRequest {
      clientId: string;
      email: string;
      firstName: string;
      lastName: string;
      tempPassword: string;
    }
    
    const handler = async (req: Request): Promise<Response> => {
      );
      }
    
      try {
        const { clientId, email, firstName, lastName, tempPassword }: InvitationRequest = await req.json();
    
        const portalUrl = `${siteUrl}/portal/login`;
    
        const emailHtml = `
          <!DOCTYPE html>
          <html>
            <head>
              <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
                .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
                .button { display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin: 20px 0; }
                .credentials { background: white; padding: 20px; border-radius: 6px; margin: 20px 0; border-left: 4px solid #667eea; }
                .footer { text-align: center; margin-top: 30px; color: #666; font-size: 12px; }
                .warning { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; border-radius: 4px; }
              </style>
            </head>
            <body>
              <div class="container">
                <div class="header">
                  <h1>Welcome to Your Client Portal!</h1>
                </div>
                <div class="content">
                  <p>Hello ${firstName} ${lastName},</p>
                  
                  <p>Your client portal account has been activated. You now have secure access to:</p>
                  
                  <ul>
                    <li>View and manage appointments</li>
                    <li>Communicate with your care team</li>
                    <li>Access your billing information</li>
                    <li>View treatment progress and resources</li>
                    <li>Update your profile and preferences</li>
                  </ul>
    
                  <div class="credentials">
                    <h3>Your Login Credentials</h3>
                    <p><strong>Email:</strong> ${email}</p>
                    <p><strong>Temporary Password:</strong> ${tempPassword}</p>
                  </div>
    
                  <div class="warning">
                    <strong>⚠️ Important:</strong> You'll be required to verify your email and change your password on first login.
                  </div>
    
                  <div style="text-align: center;">
                    <a href="${portalUrl}" class="button">Access Your Portal</a>
                  </div>
    
                  <p><strong>Portal URL:</strong> <a href="${portalUrl}">${portalUrl}</a></p>
    
                  <div class="footer">
                    <p>If you didn't request this account, please contact our office immediately.</p>
                    <p>For assistance, please reach out to your care team.</p>
                    <p>&copy; ${new Date().getFullYear()} Mental Health Practice. All rights reserved.</p>
                  </div>
                </div>
              </div>
            </body>
          </html>
        `;
    
        const emailResponse = await resend.emails.send({
          from: "CHC Therapy Client Portal <support@chctherapy.com>",
          to: [email],
          subject: "Your Client Portal Account is Ready!",
          html: emailHtml,
        });
    
        // Log the invitation
        // Using direct database connection
    await query(/* INSERT INTO portal_access_log - TODO: Convert this manually */) || 'unknown',
        });
    
        return new Response(JSON.stringify({ success: true, emailResponse }), {
          status: 200,
          headers: { "Content-Type": "application/json", ...CORS_HEADERS },
        });
      } catch (error: any) {
        return new Response(
          JSON.stringify({ error: 'Invitation failed' }),
          {
            status: 500,
            headers: { "Content-Type": "application/json", ...CORS_HEADERS },
          }
        );
      }
    };
    
    serve(handler);

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
