/**
 * advancedmd-auth Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    interface AuthRequest {
      environment: 'sandbox' | 'production';
      grant_type: 'client_credentials' | 'refresh_token';
      client_id: string;
      client_secret: string;
      refresh_token?: string;
    }
    
    serve(async (req) => {
      // CORS headers
      ,
        });
      }
    
      try {
        const { environment, grant_type, client_id, client_secret, refresh_token }: AuthRequest = await req.json();
    
        // Validate environment
        if (environment !== 'sandbox' && environment !== 'production') {
          throw new Error('Invalid environment');
        }
    
        // Get base URL from environment
        const baseUrl = environment === 'production'
          ? process.env.ADVANCEDMD_PROD_BASE_URL || 'https://api.advancedmd.com/v1'
          : process.env.ADVANCEDMD_SANDBOX_BASE_URL || 'https://api-sandbox.advancedmd.com/v1';
    
        // Build request body
        const body: Record<string, string> = {
          grant_type,
          client_id,
          client_secret,
        };
    
        if (grant_type === 'refresh_token' && refresh_token) {
          body.refresh_token = refresh_token;
        }
    
        // Make OAuth request to AdvancedMD
        const response = await fetch(`${baseUrl}/oauth/token`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json',
          },
          body: new URLSearchParams(body),
        });
    
        if (!response.ok) {
          const errorText = await response.text();
          console.error('[AdvancedMD Auth] Error:', errorText);
          throw new Error(`Authentication failed: ${response.status} ${errorText}`);
        }
    
        const data = await response.json();
    
        return new Response(JSON.stringify(data), {
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
          },
        });
    
      } catch (error) {
        console.error('[AdvancedMD Auth] Error:', error);
        return new Response(
          JSON.stringify({
            error: error instanceof Error ? error.message : 'Authentication failed',
          }),
          {
            status: 500,
            headers: {
              'Content-Type': 'application/json',
              'Access-Control-Allow-Origin': '*',
            },
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
