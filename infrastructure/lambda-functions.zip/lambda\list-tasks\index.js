/**
 * list-tasks Lambda Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();
    const { assigned_to, status, limit = '50', offset = '0' } = event.queryStringParameters || {};

    let query = `
      SELECT
        t.*,
        p.first_name as assigned_to_first_name,
        p.last_name as assigned_to_last_name,
        c.first_name as client_first_name,
        c.last_name as client_last_name
      FROM public.tasks t
      LEFT JOIN public.profiles p ON t.assigned_to = p.id
      LEFT JOIN public.clients c ON t.client_id = c.id
      WHERE 1=1
    `;

    const params = [];
    let paramCount = 0;

    if (assigned_to) {
      paramCount++;
      query += ` AND t.assigned_to = $${paramCount}`;
      params.push(assigned_to);
    }

    if (status) {
      paramCount++;
      query += ` AND t.status = $${paramCount}`;
      params.push(status);
    }

    query += ` ORDER BY t.due_date ASC NULLS LAST, t.created_at DESC`;
    query += ` LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await client.query(query, params);

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: result.rows })
    };

  } catch (error) {
    console.error('[list-tasks] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
