const { Client } = require('pg');
const AWS = require('aws-sdk');
const fs = require('fs');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

exports.handler = async (event) => {
  let client;

  try {
    // Get database credentials from Secrets Manager
    const secretResponse = await secretsManager.getSecretValue({
      SecretId: 'mentalspace-ehr-db-credentials'
    }).promise();

    const dbCredentials = JSON.parse(secretResponse.SecretString);

    // Connect to Aurora
    client = new Client({
      host: process.env.DATABASE_HOST,
      port: 5432,
      database: 'mentalspaceehr',
      user: dbCredentials.username,
      password: dbCredentials.password,
      ssl: {
        rejectUnauthorized: false
      }
    });

    await client.connect();
    console.log('✅ Connected to Aurora');

    // Create migrations tracking table
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version TEXT PRIMARY KEY,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      );
    `);

    // Get the migration SQL from the event (sent via API Gateway)
    const { migrationName, migrationSQL } = JSON.parse(event.body || '{}');

    if (!migrationName || !migrationSQL) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing migrationName or migrationSQL' })
      };
    }

    // Check if already applied
    const { rows } = await client.query(
      'SELECT version FROM schema_migrations WHERE version = $1',
      [migrationName]
    );

    if (rows.length > 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({
          status: 'skipped',
          message: `Migration ${migrationName} already applied`
        })
      };
    }

    // Apply migration
    await client.query('BEGIN');
    await client.query(migrationSQL);
    await client.query(
      'INSERT INTO schema_migrations (version) VALUES ($1)',
      [migrationName]
    );
    await client.query('COMMIT');

    return {
      statusCode: 200,
      body: JSON.stringify({
        status: 'success',
        message: `Migration ${migrationName} applied successfully`
      })
    };

  } catch (error) {
    if (client) {
      try {
        await client.query('ROLLBACK');
      } catch (rollbackError) {
        console.error('Rollback error:', rollbackError);
      }
    }

    console.error('Migration error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        status: 'error',
        message: error.message
      })
    };
  } finally {
    if (client) {
      await client.end();
    }
  }
};
