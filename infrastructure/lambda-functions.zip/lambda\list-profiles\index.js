/**
 * list-profiles Lambda Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();
    const { role, search, status = 'active', limit = '50', offset = '0' } = event.queryStringParameters || {};

    let query = `
      SELECT
        id, email, first_name, last_name, role, phone_number,
        license_type, license_number, license_state, npi_number,
        is_supervisor, supervisor_id, status, title, bio,
        specialties, credentials, accepts_new_clients,
        created_at, updated_at
      FROM public.profiles
      WHERE 1=1
    `;

    const params = [];
    let paramCount = 0;

    if (role) {
      paramCount++;
      query += ` AND role = $${paramCount}`;
      params.push(role);
    }

    if (status) {
      paramCount++;
      query += ` AND status = $${paramCount}`;
      params.push(status);
    }

    if (search) {
      paramCount++;
      query += ` AND (
        LOWER(first_name) LIKE LOWER($${paramCount}) OR
        LOWER(last_name) LIKE LOWER($${paramCount}) OR
        LOWER(email) LIKE LOWER($${paramCount})
      )`;
      params.push(`%${search}%`);
    }

    // Count total for pagination
    const countQuery = `SELECT COUNT(*) as total FROM (${query}) as filtered`;
    const countResult = await client.query(countQuery, params);
    const total = parseInt(countResult.rows[0].total);

    // Add pagination
    query += ` ORDER BY last_name, first_name`;
    query += ` LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await client.query(query, params);

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: result.rows,
        pagination: {
          total,
          limit: parseInt(limit),
          offset: parseInt(offset),
          hasMore: (parseInt(offset) + result.rows.length) < total
        }
      })
    };

  } catch (error) {
    console.error('[list-profiles] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
