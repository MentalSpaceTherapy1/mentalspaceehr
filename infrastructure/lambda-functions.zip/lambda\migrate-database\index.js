const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

exports.handler = async (event) => {
  let client;

  try {
    // Get database credentials from Secrets Manager
    const secretResponse = await secretsManager.getSecretValue({
      SecretId: process.env.DATABASE_SECRET_ARN
    }).promise();

    const dbCredentials = JSON.parse(secretResponse.SecretString);

    // Connect to Aurora
    client = new Client({
      host: dbCredentials.host,
      port: dbCredentials.port || 5432,
      database: process.env.DATABASE_NAME,
      user: dbCredentials.username,
      password: dbCredentials.password,
      ssl: {
        rejectUnauthorized: false
      }
    });

    await client.connect();
    console.log('✅ Connected to Aurora');

    // Create migrations tracking table
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version TEXT PRIMARY KEY,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      );
    `);

    // Parse request body
    const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
    const { migrationName, migrationSQL, dryRun } = body || {};

    if (!migrationName || !migrationSQL) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ error: 'Missing migrationName or migrationSQL' })
      };
    }

    // Check if already applied
    const { rows } = await client.query(
      'SELECT version FROM schema_migrations WHERE version = $1',
      [migrationName]
    );

    if (rows.length > 0) {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          status: 'skipped',
          message: `Migration ${migrationName} already applied`,
          appliedAt: rows[0].applied_at
        })
      };
    }

    if (dryRun) {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          status: 'dry-run',
          message: `Migration ${migrationName} validated (not applied)`,
          wouldApply: true
        })
      };
    }

    // Apply migration
    await client.query('BEGIN');
    try {
      await client.query(migrationSQL);
      await client.query(
        'INSERT INTO schema_migrations (version) VALUES ($1)',
        [migrationName]
      );
      await client.query('COMMIT');

      console.log(`✅ Applied migration: ${migrationName}`);

      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({
          status: 'success',
          message: `Migration ${migrationName} applied successfully`
        })
      };
    } catch (migrationError) {
      await client.query('ROLLBACK');
      throw migrationError;
    }

  } catch (error) {
    console.error('Migration error:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        status: 'error',
        message: error.message,
        stack: error.stack
      })
    };
  } finally {
    if (client) {
      await client.end();
    }
  }
};
