/**
 * create-test-portal-user Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    );
      }
    
      try {
        const supabaseAdmin = createClient(
          process.env.SUPABASE_URL ?? '',
          process.env.SUPABASE_SERVICE_ROLE_KEY ?? '',
          {
            auth: {
              autoRefreshToken: false,
              persistSession: false
            }
          }
        );
    
        // Create test user credentials
        const testEmail = `testclient${Date.now()}@example.com`;
        const testPassword = 'TestClient123!';
    
        // Create auth user
        const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
          email: testEmail,
          password: testPassword,
          email_confirm: true,
          user_metadata: {
            first_name: 'Test',
            last_name: 'Client'
          }
        });
    
        if (authError) throw authError;
        if (!authData.user) throw new Error('No user created');
    
        // Generate MRN
        const { data: mrnData, error: mrnError } = await supabaseAdmin.rpc('generate_mrn');
        if (mrnError) throw mrnError;
    
        // Create client record
        const { data: clientData, error: clientError } = await supabaseAdmin
          .from('clients')
          .insert({
            first_name: 'Test',
            last_name: 'Client',
            medical_record_number: mrnData,
            date_of_birth: '1990-01-01',
            email: testEmail,
            primary_phone: '555-0100',
            primary_phone_type: 'Mobile',
            street1: '123 Test St',
            city: 'Test City',
            state: 'CA',
            zip_code: '90001',
            portal_enabled: true,
            portal_user_id: authData.user.id,
            status: 'Active'
          })
          .select()
          .single();
    
        if (clientError) throw clientError;
    
        // Assign client_user role
        const { error: roleError } = await supabaseAdmin
          .from('user_roles')
          .insert({
            user_id: authData.user.id,
            role: 'client_user',
            assigned_by: authData.user.id
          });
    
        if (roleError) throw roleError;
    
        return new Response(
          JSON.stringify({
            success: true,
            credentials: {
              email: testEmail,
              password: testPassword,
              userId: authData.user.id,
              clientId: clientData.id
            },
            message: 'Test portal user created successfully. Use these credentials to log in.'
          }),
          {
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
            status: 200,
          }
        );
    
      } catch (error) {
        return new Response(
          JSON.stringify({ error: 'Failed to create test user' }),
          {
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
            status: 500,
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
