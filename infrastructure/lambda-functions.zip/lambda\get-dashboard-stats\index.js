/**
 * get-dashboard-stats Lambda Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();

    // Get total clients
    const clientsResult = await client.query(`
      SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE status = 'active') as active
      FROM public.clients
    `);

    // Get total appointments today
    const appointmentsTodayResult = await client.query(`
      SELECT COUNT(*) as total
      FROM public.appointments
      WHERE appointment_date = CURRENT_DATE
    `);

    // Get upcoming appointments (next 7 days)
    const upcomingAppointmentsResult = await client.query(`
      SELECT COUNT(*) as total
      FROM public.appointments
      WHERE appointment_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '7 days'
      AND status IN ('scheduled', 'confirmed')
    `);

    // Get pending tasks
    const pendingTasksResult = await client.query(`
      SELECT COUNT(*) as total
      FROM public.tasks
      WHERE status != 'Completed'
    `);

    // Get overdue tasks
    const overdueTasksResult = await client.query(`
      SELECT COUNT(*) as total
      FROM public.tasks
      WHERE status != 'Completed'
      AND due_date < CURRENT_TIMESTAMP
    `);

    // Get total notes this month
    const notesThisMonthResult = await client.query(`
      SELECT COUNT(*) as total
      FROM public.clinical_notes
      WHERE created_at >= DATE_TRUNC('month', CURRENT_DATE)
    `);

    // Get total staff
    const staffResult = await client.query(`
      SELECT COUNT(*) as total
      FROM public.profiles
      WHERE status = 'active'
      AND role IN ('therapist', 'supervisor', 'administrator')
    `);

    // Get recent activities (last 10 appointments)
    const recentActivitiesResult = await client.query(`
      SELECT
        a.id,
        a.appointment_date,
        a.start_time,
        a.status,
        c.first_name as client_first_name,
        c.last_name as client_last_name,
        p.first_name as clinician_first_name,
        p.last_name as clinician_last_name
      FROM public.appointments a
      LEFT JOIN public.clients c ON a.client_id = c.id
      LEFT JOIN public.profiles p ON a.clinician_id = p.id
      ORDER BY a.appointment_date DESC, a.start_time DESC
      LIMIT 10
    `);

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: {
          clients: {
            total: parseInt(clientsResult.rows[0].total),
            active: parseInt(clientsResult.rows[0].active)
          },
          appointments: {
            today: parseInt(appointmentsTodayResult.rows[0].total),
            upcoming: parseInt(upcomingAppointmentsResult.rows[0].total)
          },
          tasks: {
            pending: parseInt(pendingTasksResult.rows[0].total),
            overdue: parseInt(overdueTasksResult.rows[0].total)
          },
          notes: {
            thisMonth: parseInt(notesThisMonthResult.rows[0].total)
          },
          staff: {
            active: parseInt(staffResult.rows[0].total)
          },
          recentActivities: recentActivitiesResult.rows
        }
      })
    };

  } catch (error) {
    console.error('[get-dashboard-stats] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
