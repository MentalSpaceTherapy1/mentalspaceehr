/**
 * get-user-roles Lambda Function
 * Fetches user roles from the database
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;

  if (!secretArn) {
    throw new Error('DB_SECRET_ARN environment variable is not set');
  }

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: secretArn
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  console.log('[get-user-roles] Event:', JSON.stringify(event));

  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({ message: 'OK' })
    };
  }

  try {
    // Extract user ID from query parameters or path
    const userId = event.queryStringParameters?.user_id ||
                   event.pathParameters?.userId ||
                   event.requestContext?.authorizer?.claims?.sub; // From Cognito JWT

    if (!userId) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({ error: 'User ID is required' })
      };
    }

    const client = await getDbClient();

    // Fetch user role from profiles table
    const result = await client.query(
      'SELECT role, email, first_name, last_name FROM public.profiles WHERE id = $1',
      [userId]
    );

    if (result.rows.length === 0) {
      console.log('[get-user-roles] User not found:', userId);
      return {
        statusCode: 404,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          error: 'User not found',
          userId
        })
      };
    }

    const userProfile = result.rows[0];
    const roles = userProfile.role ? [userProfile.role] : [];

    console.log('[get-user-roles] Found user:', {
      userId,
      email: userProfile.email,
      role: userProfile.role,
      roles
    });

    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        userId,
        roles,
        count: roles.length,
        profile: {
          email: userProfile.email,
          firstName: userProfile.first_name,
          lastName: userProfile.last_name,
          role: userProfile.role
        }
      })
    };

  } catch (error) {
    console.error('[get-user-roles] Error:', error);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: error.message })
    };
  }
};
