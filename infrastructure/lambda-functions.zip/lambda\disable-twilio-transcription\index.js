/**
 * disable-twilio-transcription Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    import "https://deno.land/x/xhr@0.1.0/mod.ts";
    serve(async (req) => {
      );
      }
    
      try {
        const { roomSid, trackSid } = await req.json();
    
        if (!roomSid || !trackSid) {
          throw new Error('Room SID and Track SID are required');
        }
    
        const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID;
        const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN;
    
        if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN) {
          throw new Error('Twilio credentials not configured');
        }
    
        // Disable Voice Intelligence for the track
        const twilioUrl = `https://voice.twilio.com/v1/Rooms/${roomSid}/Participants/${trackSid}`;
        const authHeader = 'Basic ' + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`);
    
        const response = await fetch(twilioUrl, {
          method: 'DELETE',
          headers: {
            'Authorization': authHeader,
          },
        });
    
        if (!response.ok && response.status !== 404) {
          const errorText = await response.text();
          console.error('Twilio API error:', response.status, errorText);
          throw new Error('Failed to disable Twilio transcription');
        }
    
        return new Response(
          JSON.stringify({ success: true }),
          { 
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } 
          }
        );
    
      } catch (error) {
        console.error('Error:', error);
        return new Response(
          JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
          { 
            status: 500,
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } 
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
