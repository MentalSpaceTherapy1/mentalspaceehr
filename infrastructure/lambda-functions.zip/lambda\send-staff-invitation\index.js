/**
 * send-staff-invitation Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    const resend = new Resend(process.env.RESEND_API_KEY);
    
    // Validation schema
    const requestSchema = z.object({
      userId: z.string().uuid('Invalid user ID format'),
      tempPassword: z.string().min(8).max(100),
    });
    
    serve(async (req) => {
      );
      }
    
      try {
        const rawBody = await req.json();
        
        // Validate input
        const validation = requestSchema.safeParse(rawBody);
        if (!validation.success) {
          return new Response(
            JSON.stringify({ 
              error: 'Invalid input',
              details: validation.error.issues 
            }),
            {
              status: 400,
              headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
            }
          );
        }
    
        const { userId, tempPassword } = validation.data;
    
        const supabaseAdmin = createClient(
          process.env.SUPABASE_URL ?? '',
          process.env.SUPABASE_SERVICE_ROLE_KEY ?? '',
          {
            auth: {
              autoRefreshToken: false,
              persistSession: false
            }
          }
        );
    
        // Get user details
        const { data: profile, error: profileError } = await supabaseAdmin
          .from('profiles')
          .select('first_name, last_name, email')
          .eq('id', userId)
          .single();
    
        if (profileError) throw profileError;
    
        // Get practice settings for email templates
        const { data: settings } = await supabaseAdmin
          .from('practice_settings')
          .select('portal_email_templates')
          .maybeSingle();
    
        const portalUrl = `${process.env.SUPABASE_URL?.replace('https://', 'https://mental-space-ai.lovable.app') || 'https://mental-space-ai.lovable.app'}`;
        
        // Default staff invitation template
        const defaultSubject = 'Your Staff Account is Ready - Mental Space AI';
        const defaultBody = `Hello ${profile.first_name} ${profile.last_name},
    
    Your staff account for Mental Space AI has been created. You now have access to the clinical management system.
    
    Login Credentials:
    Email: ${profile.email}
    Temporary Password: ${tempPassword}
    
    ⚠️ Important: You'll be required to change your password upon first login for security purposes.
    
    Login URL: ${portalUrl}
    
    If you have any questions or need assistance, please contact your administrator.
    
    Best regards,
    Mental Space AI Team`;
    
        // Use custom template if available
        const templates = settings?.portal_email_templates as any;
        const subject = templates?.staff_invitation_subject || defaultSubject;
        let body = templates?.staff_invitation_body || defaultBody;
    
        // Replace template variables
        body = body
          .replace(/{firstName}/g, profile.first_name)
          .replace(/{lastName}/g, profile.last_name)
          .replace(/{email}/g, profile.email)
          .replace(/{tempPassword}/g, tempPassword)
          .replace(/{portalUrl}/g, portalUrl);
    
        const emailResponse = await resend.emails.send({
          from: "Mental Space AI <onboarding@resend.dev>",
          to: [profile.email],
          subject: subject,
          text: body,
        });
    
        return new Response(
          JSON.stringify({ 
            success: true,
            message: 'Invitation email sent successfully' 
          }),
          {
            status: 200,
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
          }
        );
      } catch (error) {
        return new Response(
          JSON.stringify({ error: 'Invitation failed' }),
          {
            status: 400,
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
