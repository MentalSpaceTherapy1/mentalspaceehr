/**
 * update-telehealth-session Lambda Function
 * Updates telehealth session status and metadata
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'PUT, PATCH, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();
    const sessionId = event.pathParameters?.sessionId || event.queryStringParameters?.session_id;
    const body = JSON.parse(event.body || '{}');

    if (!sessionId) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'session_id is required' })
      };
    }

    // Build UPDATE query dynamically based on provided fields
    const updateFields = [];
    const values = [];
    let paramIndex = 1;

    if (body.status) {
      updateFields.push(`status = $${paramIndex++}`);
      values.push(body.status);

      // Auto-set timestamps based on status
      if (body.status === 'active' && !body.started_at) {
        updateFields.push(`started_at = $${paramIndex++}`);
        values.push(new Date().toISOString());
      } else if (body.status === 'ended') {
        updateFields.push(`ended_at = $${paramIndex++}`);
        values.push(new Date().toISOString());

        // Calculate duration if not provided
        if (body.duration_seconds === undefined) {
          updateFields.push(`duration_seconds = EXTRACT(EPOCH FROM (NOW() - started_at))::INTEGER`);
        }
      }
    }

    if (body.started_at) {
      updateFields.push(`started_at = $${paramIndex++}`);
      values.push(body.started_at);
    }

    if (body.ended_at) {
      updateFields.push(`ended_at = $${paramIndex++}`);
      values.push(body.ended_at);
    }

    if (body.duration_seconds !== undefined) {
      updateFields.push(`duration_seconds = $${paramIndex++}`);
      values.push(body.duration_seconds);
    }

    if (body.consent_id) {
      updateFields.push(`consent_id = $${paramIndex++}`);
      values.push(body.consent_id);
    }

    if (body.consent_verified !== undefined) {
      updateFields.push(`consent_verified = $${paramIndex++}`);
      values.push(body.consent_verified);
    }

    if (body.consent_verification_date) {
      updateFields.push(`consent_verification_date = $${paramIndex++}`);
      values.push(body.consent_verification_date);
    }

    if (updateFields.length === 0) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'No fields to update' })
      };
    }

    // Add session_id to values
    values.push(sessionId);

    const updateQuery = `
      UPDATE public.telehealth_sessions
      SET ${updateFields.join(', ')}, updated_at = NOW()
      WHERE session_id = $${paramIndex}
      RETURNING *
    `;

    const result = await client.query(updateQuery, values);

    if (result.rows.length === 0) {
      return {
        statusCode: 404,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Session not found' })
      };
    }

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify(result.rows[0])
    };

  } catch (error) {
    console.error('[update-telehealth-session] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
