/**
 * create-session-participant Lambda Function
 * Tracks participant joining telehealth session
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();
    const body = JSON.parse(event.body || '{}');

    const {
      session_id,
      user_id,
      participant_name,
      participant_role,
      device_fingerprint = '',
      ip_address = '',
      user_agent = ''
    } = body;

    if (!session_id || !user_id || !participant_name || !participant_role) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'session_id, user_id, participant_name, and participant_role are required' })
      };
    }

    // Check if participant already exists
    const checkQuery = `
      SELECT * FROM public.session_participants
      WHERE session_id = $1 AND user_id = $2
    `;
    const checkResult = await client.query(checkQuery, [session_id, user_id]);

    if (checkResult.rows.length > 0) {
      // Update existing participant
      const updateQuery = `
        UPDATE public.session_participants
        SET
          connection_state = 'connected',
          joined_at = NOW(),
          user_agent = $3
        WHERE session_id = $1 AND user_id = $2
        RETURNING *
      `;
      const updateResult = await client.query(updateQuery, [session_id, user_id, user_agent]);
      return {
        statusCode: 200,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify(updateResult.rows[0])
      };
    }

    // Create new participant
    const insertQuery = `
      INSERT INTO public.session_participants (
        id, session_id, user_id, participant_name, participant_role,
        device_fingerprint, ip_address, user_agent, connection_state, joined_at
      ) VALUES (gen_random_uuid(), $1, $2, $3, $4, $5, $6, $7, 'connected', NOW())
      RETURNING *
    `;

    const result = await client.query(insertQuery, [
      session_id,
      user_id,
      participant_name,
      participant_role,
      device_fingerprint,
      ip_address,
      user_agent
    ]);

    if (result.rows.length === 0) {
      throw new Error('Failed to create session participant');
    }

    return {
      statusCode: 201,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify(result.rows[0])
    };

  } catch (error) {
    console.error('[create-session-participant] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
