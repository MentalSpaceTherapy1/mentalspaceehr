/**
 * list-claims Lambda Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();
    const { client_id, status, start_date, end_date, limit = '50', offset = '0' } = event.queryStringParameters || {};

    let query = `
      SELECT
        ic.*,
        c.first_name as client_first_name,
        c.last_name as client_last_name,
        p.first_name as provider_first_name,
        p.last_name as provider_last_name
      FROM public.insurance_claims ic
      LEFT JOIN public.clients c ON ic.client_id = c.id
      LEFT JOIN public.profiles p ON ic.provider_id = p.id
      WHERE 1=1
    `;

    const params = [];
    let paramCount = 0;

    if (client_id) {
      paramCount++;
      query += ` AND ic.client_id = $${paramCount}`;
      params.push(client_id);
    }

    if (status) {
      paramCount++;
      query += ` AND ic.status = $${paramCount}`;
      params.push(status);
    }

    if (start_date) {
      paramCount++;
      query += ` AND ic.service_date >= $${paramCount}`;
      params.push(start_date);
    }

    if (end_date) {
      paramCount++;
      query += ` AND ic.service_date <= $${paramCount}`;
      params.push(end_date);
    }

    // Count total for pagination
    const countQuery = `SELECT COUNT(*) as total FROM (${query}) as filtered`;
    const countResult = await client.query(countQuery, params);
    const total = parseInt(countResult.rows[0].total);

    // Add pagination
    query += ` ORDER BY ic.service_date DESC, ic.created_at DESC`;
    query += ` LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await client.query(query, params);

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        data: result.rows,
        pagination: {
          total,
          limit: parseInt(limit),
          offset: parseInt(offset),
          hasMore: (parseInt(offset) + result.rows.length) < total
        }
      })
    };

  } catch (error) {
    console.error('[list-claims] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
