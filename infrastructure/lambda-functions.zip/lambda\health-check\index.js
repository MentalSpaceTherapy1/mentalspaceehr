/**
 * health-check Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    // Handle CORS preflight requests
      );
      }
    
      try {
        const supabaseUrl = process.env.SUPABASE_URL!;
        const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
        
        // Using direct database connection
    const checks = {
          timestamp: new Date().toISOString(),
          status: 'healthy',
          checks: {} as Record<string, any>,
        };
    
        // Check database connectivity
        try {
          const { error } = await query('SELECT count FROM profiles').limit(1);
          checks.checks.database = {
            status: error ? 'unhealthy' : 'healthy',
            message: error ? error.message : 'Connected',
          };
          if (error) checks.status = 'degraded';
        } catch (e) {
          checks.checks.database = {
            status: 'unhealthy',
            message: e instanceof Error ? e.message : 'Unknown error',
          };
          checks.status = 'unhealthy';
        }
    
        // Check auth service
        try {
          const { data, error } = await supabase.auth.admin.listUsers({ page: 1, perPage: 1 });
          checks.checks.auth = {
            status: error ? 'unhealthy' : 'healthy',
            message: error ? error.message : 'Connected',
          };
          if (error) checks.status = 'degraded';
        } catch (e) {
          checks.checks.auth = {
            status: 'unhealthy',
            message: e instanceof Error ? e.message : 'Unknown error',
          };
          checks.status = 'unhealthy';
        }
    
        // Check storage
        try {
          const { data, error } = await supabase.storage.listBuckets();
          checks.checks.storage = {
            status: error ? 'unhealthy' : 'healthy',
            message: error ? error.message : `${data?.length || 0} buckets available`,
          };
          if (error) checks.status = 'degraded';
        } catch (e) {
          checks.checks.storage = {
            status: 'unhealthy',
            message: e instanceof Error ? e.message : 'Unknown error',
          };
          checks.status = 'unhealthy';
        }
    
        const statusCode = checks.status === 'healthy' ? 200 : checks.status === 'degraded' ? 207 : 503;
    
        return new Response(JSON.stringify(checks, null, 2), {
          status: statusCode,
          headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        });
      } catch (error) {
        return new Response(
          JSON.stringify({
            status: 'unhealthy',
            message: error instanceof Error ? error.message : 'Unknown error',
            timestamp: new Date().toISOString(),
          }),
          {
            status: 503,
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
