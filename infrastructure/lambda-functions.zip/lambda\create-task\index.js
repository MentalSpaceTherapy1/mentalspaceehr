/**
 * create-task Lambda Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const {
      title,
      description,
      assigned_to,
      client_id,
      due_date,
      priority = 'medium',
      status = 'pending',
      category
    } = body;

    if (!title) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Title is required' })
      };
    }

    const client = await getDbClient();

    const result = await client.query(`
      INSERT INTO public.tasks (
        title, description, assigned_to, client_id, due_date,
        priority, status, category, created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW()
      )
      RETURNING *
    `, [
      title, description, assigned_to, client_id, due_date,
      priority, status, category
    ]);

    return {
      statusCode: 201,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: result.rows[0] })
    };

  } catch (error) {
    console.error('[create-task] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
