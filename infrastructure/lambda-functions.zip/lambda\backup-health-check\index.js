/**
 * backup-health-check Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    interface BackupStatus {
      table: string;
      record_count: number;
      last_modified: string | null;
      status: 'healthy' | 'warning' | 'critical';
      message?: string;
    }
    
    
      );
      }
    
      try {
        const supabaseUrl = process.env.SUPABASE_URL!;
        const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
        // Using direct database connection
    console.log('Starting backup health check...');
        const backupStatuses: BackupStatus[] = [];
        const criticalTables = [
          'clients',
          'chart_notes',
          'appointments',
          'treatment_plans',
          'client_documents',
          'profiles',
          'insurance_claims',
        ];
    
        // Check each critical table
        for (const table of criticalTables) {
          try {
            const { count, error: countError } = await supabase
              .from(table)
              .select('*', { count: 'exact', head: true });
    
            if (countError) {
              backupStatuses.push({
                table,
                record_count: 0,
                last_modified: null,
                status: 'critical',
                message: `Error accessing table: ${countError.message}`,
              });
              continue;
            }
    
            // Get most recent update
            const { data: recentData } = await supabase
              .from(table)
              .select('updated_at, created_at')
              .order('updated_at', { ascending: false, nullsFirst: false })
              .limit(1)
              .single();
    
            const lastModified = recentData?.updated_at || recentData?.created_at || null;
            const recordCount = count || 0;
    
            // Determine status
            let status: 'healthy' | 'warning' | 'critical' = 'healthy';
            let message: string | undefined;
    
            if (recordCount === 0) {
              status = 'warning';
              message = 'No records found in table';
            } else if (lastModified) {
              const daysSinceUpdate = (Date.now() - new Date(lastModified).getTime()) / (1000 * 60 * 60 * 24);
              if (daysSinceUpdate > 7) {
                status = 'warning';
                message = `No updates in ${Math.floor(daysSinceUpdate)} days`;
              }
            }
    
            backupStatuses.push({
              table,
              record_count: recordCount,
              last_modified: lastModified,
              status,
              message,
            });
          } catch (error: any) {
            backupStatuses.push({
              table,
              record_count: 0,
              last_modified: null,
              status: 'critical',
              message: error.message,
            });
          }
        }
    
        // Check backup age (simulate with system_health_metrics)
        const { data: healthMetrics } = await supabase
          .from('system_health_metrics')
          .select('metric_timestamp')
          .order('metric_timestamp', { ascending: false })
          .limit(1)
          .single();
    
        const lastBackup = healthMetrics?.metric_timestamp 
          ? new Date(healthMetrics.metric_timestamp)
          : null;
    
        let backupAge = 'unknown';
        let backupStatus: 'healthy' | 'warning' | 'critical' = 'healthy';
        
        if (lastBackup) {
          const hoursSinceBackup = (Date.now() - lastBackup.getTime()) / (1000 * 60 * 60);
          backupAge = `${Math.floor(hoursSinceBackup)} hours ago`;
          
          if (hoursSinceBackup > 48) {
            backupStatus = 'critical';
          } else if (hoursSinceBackup > 24) {
            backupStatus = 'warning';
          }
        } else {
          backupStatus = 'critical';
        }
    
        const overallHealth = {
          backup_age: backupAge,
          backup_status: backupStatus,
          tables_healthy: backupStatuses.filter(s => s.status === 'healthy').length,
          tables_warning: backupStatuses.filter(s => s.status === 'warning').length,
          tables_critical: backupStatuses.filter(s => s.status === 'critical').length,
          total_records: backupStatuses.reduce((sum, s) => sum + s.record_count, 0),
        };
    
        // Log the health check
        await query(/* INSERT INTO audit_logs - TODO: Convert this manually */);
    
        console.log('Backup health check completed');
    
        return new Response(
          JSON.stringify({
            success: true,
            timestamp: new Date().toISOString(),
            overall_health: overallHealth,
            table_statuses: backupStatuses,
          }),
          { headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
        );
      } catch (error: any) {
        console.error('Error during backup health check:', error);
        return new Response(
          JSON.stringify({ error: error.message }),
          { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
