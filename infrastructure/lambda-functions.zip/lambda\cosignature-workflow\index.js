/**
 * cosignature-workflow Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    interface WorkflowEvent {
      action: 'submit' | 'review' | 'revise' | 'cosign' | 'reject';
      cosignatureId: string;
      noteId: string;
      userId: string;
      data?: any;
    }
    
    
      // Handle CORS preflight requests
      );
      }
    
      try {
        const supabaseClient = createClient(
          process.env.SUPABASE_URL ?? '',
          process.env.SUPABASE_SERVICE_ROLE_KEY ?? ''
        );
    
        const { action, cosignatureId, noteId, userId, data }: WorkflowEvent = await req.json();
    
        // Fetch current cosignature
        const { data: cosignature, error: fetchError } = await supabaseClient
          .from('note_cosignatures')
          .select('*')
          .eq('id', cosignatureId)
          .single();
    
        if (fetchError) {
          throw new Error(`Failed to fetch cosignature: ${fetchError.message}`);
        }
    
        let updates: any = {};
        let noteUpdates: any = {};
        let notificationData: any = null;
    
        // Process workflow based on action
        switch (action) {
          case 'submit':
            // Clinician submits note for cosign
            updates = {
              status: 'Pending Review',
              clinician_signed: true,
              clinician_signed_date: new Date().toISOString(),
              submitted_for_cosign_date: new Date().toISOString(),
              due_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days from now
            };
    
            noteUpdates = {
              locked: true,
              locked_date: new Date().toISOString(),
              locked_by: userId
            };
    
            notificationData = {
              type: 'new_cosignature',
              supervisorId: cosignature.supervisor_id,
              clinicianId: userId
            };
            break;
    
          case 'review':
            // Supervisor opens note for review
            updates = {
              status: 'Under Review',
              reviewed_date: new Date().toISOString()
            };
            break;
    
          case 'revise':
            // Supervisor requests revisions
            const revisionHistory = Array.isArray(cosignature.revision_history)
              ? cosignature.revision_history
              : [];
            
            revisionHistory.push({
              revisionDate: new Date().toISOString(),
              revisionReason: data?.revisionReason || 'Revisions requested',
              revisionCompleteDate: null
            });
    
            updates = {
              status: 'Revisions Requested',
              revisions_requested: true,
              revision_details: data?.revisionReason,
              revision_history: revisionHistory,
              reviewed_date: new Date().toISOString()
            };
    
            noteUpdates = {
              locked: false,
              locked_date: null,
              locked_by: null
            };
    
            notificationData = {
              type: 'revisions_requested',
              clinicianId: cosignature.clinician_id,
              supervisorId: userId
            };
            break;
    
          case 'cosign':
            // Supervisor cosigns the note
            updates = {
              status: 'Cosigned',
              supervisor_cosigned: true,
              supervisor_cosigned_date: new Date().toISOString(),
              supervisor_comments: data?.comments,
              time_spent_reviewing: data?.timeSpent,
              is_incident_to: data?.isIncidentTo || false,
              supervisor_attestation: data?.attestation
            };
    
            noteUpdates = {
              locked: true,
              locked_date: new Date().toISOString(),
              locked_by: userId,
              supervised_by: userId,
              supervision_date: new Date().toISOString()
            };
    
            notificationData = {
              type: 'cosigned',
              clinicianId: cosignature.clinician_id,
              supervisorId: userId
            };
            break;
    
          case 'reject':
            // Supervisor rejects the note
            updates = {
              status: 'Returned',
              supervisor_comments: data?.comments,
              reviewed_date: new Date().toISOString()
            };
    
            noteUpdates = {
              locked: false,
              locked_date: null,
              locked_by: null
            };
    
            notificationData = {
              type: 'rejected',
              clinicianId: cosignature.clinician_id,
              supervisorId: userId
            };
            break;
    
          default:
            throw new Error(`Unknown action: ${action}`);
        }
    
        // Update cosignature record
        const { error: updateError } = await supabaseClient
          .from('note_cosignatures')
          .update(updates)
          .eq('id', cosignatureId);
    
        if (updateError) {
          throw new Error(`Failed to update cosignature: ${updateError.message}`);
        }
    
        // Update clinical note if needed
        if (Object.keys(noteUpdates).length > 0) {
          const { error: noteError } = await supabaseClient
            .from('clinical_notes')
            .update(noteUpdates)
            .eq('id', noteId);
        }
    
        // Send notification if needed
        if (notificationData) {
          try {
            await supabaseClient.functions.invoke('supervision-notifications', {
              body: {
                ...notificationData,
                cosignatureId
              }
            });
          } catch (notifError) {
            // Notification failures are non-critical
          }
        }
    
        return new Response(
          JSON.stringify({ 
            success: true, 
            action,
            cosignatureId,
            newStatus: updates.status 
          }),
          { 
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
            status: 200 
          }
        );
    
      } catch (error) {
        return new Response(
          JSON.stringify({ 
            success: false, 
            error: 'Workflow action failed'
          }),
          { 
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
            status: 500 
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
