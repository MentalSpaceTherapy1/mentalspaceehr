/**
 * get-telehealth-session Lambda Function
 * Fetches telehealth session by session_id with related appointment data
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();

    // Get session_id from path parameters
    const sessionId = event.pathParameters?.sessionId || event.queryStringParameters?.session_id;

    if (!sessionId) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'session_id is required' })
      };
    }

    // Build tolerant candidates for session_id matching
    const raw = sessionId.trim();
    const noColon = raw.replace(/^:/, '');
    const withoutPrefix = noColon.replace(/^session_/, '');
    const withPrefix = withoutPrefix.startsWith('session_') ? withoutPrefix : `session_${withoutPrefix}`;
    const candidates = [noColon, withPrefix, withoutPrefix];

    // Query telehealth_sessions with appointment data
    const query = `
      SELECT
        ts.*,
        a.client_id as appointment_client_id,
        a.appointment_type as appointment_type,
        a.start_time as appointment_start_time
      FROM public.telehealth_sessions ts
      LEFT JOIN public.appointments a ON ts.appointment_id = a.id
      WHERE ts.session_id = ANY($1::text[])
      ORDER BY CASE
        WHEN ts.session_id = $2 THEN 2
        WHEN ts.session_id = ANY($1::text[]) THEN 1
        ELSE 0
      END DESC
      LIMIT 1
    `;

    const result = await client.query(query, [candidates, withPrefix]);

    if (result.rows.length === 0) {
      return {
        statusCode: 404,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Session not found' })
      };
    }

    const session = result.rows[0];

    // Format response to match Supabase structure
    const response = {
      ...session,
      appointments: session.appointment_id ? {
        client_id: session.appointment_client_id,
        appointment_type: session.appointment_type,
        start_time: session.appointment_start_time
      } : null
    };

    // Remove duplicate fields
    delete response.appointment_client_id;
    delete response.appointment_type;
    delete response.appointment_start_time;

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify(response)
    };

  } catch (error) {
    console.error('[get-telehealth-session] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
