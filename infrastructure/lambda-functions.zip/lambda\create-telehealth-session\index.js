/**
 * create-telehealth-session Lambda Function
 * Creates a new telehealth session
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();
    const body = JSON.parse(event.body || '{}');

    const { session_id, host_id, appointment_id, status = 'waiting' } = body;

    if (!session_id || !host_id) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'session_id and host_id are required' })
      };
    }

    // Insert new session
    const insertQuery = `
      INSERT INTO public.telehealth_sessions (
        session_id, host_id, appointment_id, status, created_at
      ) VALUES ($1, $2, $3, $4, NOW())
      RETURNING *
    `;

    const insertResult = await client.query(insertQuery, [
      session_id,
      host_id,
      appointment_id || null,
      status
    ]);

    if (insertResult.rows.length === 0) {
      throw new Error('Failed to create session');
    }

    const newSession = insertResult.rows[0];

    // Fetch appointment data if appointment_id provided
    let appointmentData = null;
    if (appointment_id) {
      const apptQuery = `
        SELECT client_id, appointment_type, start_time
        FROM public.appointments
        WHERE id = $1
      `;
      const apptResult = await client.query(apptQuery, [appointment_id]);
      if (apptResult.rows.length > 0) {
        appointmentData = apptResult.rows[0];
      }
    }

    // Format response
    const response = {
      ...newSession,
      appointments: appointmentData
    };

    return {
      statusCode: 201,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify(response)
    };

  } catch (error) {
    console.error('[create-telehealth-session] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
