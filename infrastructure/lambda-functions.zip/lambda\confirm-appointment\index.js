/**
 * confirm-appointment Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    const supabaseUrl = process.env.SUPABASE_URL!;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
    // Using direct database connection
    serve(async (req: Request): Promise<Response> => {
      );
      }
    
      try {
        const { token } = await req.json();
    
        if (!token) {
          return new Response(
            JSON.stringify({ error: "Confirmation token required" }),
            {
              status: 400,
              headers: { "Content-Type": "application/json", ...CORS_HEADERS },
            }
          );
        }
    
        // Find appointment by confirmation token
        const { data: appointment, error: findError } = await supabase
          .from('appointments')
          .select('id, client_id, status')
          .eq('reminder_confirmation_token', token)
          .maybeSingle();
    
        if (findError || !appointment) {
          return new Response(
            JSON.stringify({ error: "Invalid or expired confirmation token" }),
            {
              status: 404,
              headers: { "Content-Type": "application/json", ...CORS_HEADERS },
            }
          );
        }
    
        // Update appointment as confirmed
        const { error: updateError } = await supabase
          .from('appointments')
          .update({
            reminder_confirmed: true,
            reminder_confirmed_at: new Date().toISOString(),
            status: 'Confirmed'
          })
          .eq('id', appointment.id);
    
        if (updateError) throw updateError;
    
        // Update reminder log
        await supabase
          .from('reminder_logs')
          .update({
            status: 'confirmed',
            confirmed_at: new Date().toISOString()
          })
          .eq('appointment_id', appointment.id)
          .eq('status', 'sent');
    
        return new Response(
          JSON.stringify({ 
            success: true,
            message: "Appointment confirmed successfully" 
          }),
          {
            status: 200,
            headers: {
              "Content-Type": "application/json",
              ...CORS_HEADERS,
            },
          }
        );
      } catch (error: any) {
        return new Response(
          JSON.stringify({ error: 'Confirmation failed' }),
          {
            status: 500,
            headers: { "Content-Type": "application/json", ...CORS_HEADERS },
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
