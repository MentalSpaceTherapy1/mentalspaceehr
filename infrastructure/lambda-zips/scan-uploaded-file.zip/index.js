/**
 * scan-uploaded-file Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    serve(async (req) => {
      // Handle CORS preflight requests
      );
      }
    
      try {
        const { filePath, bucket } = await req.json();
    
        // Using direct database connection
    // Download file from storage
        const { data, error } = await supabase.storage
          .from(bucket)
          .download(filePath);
    
        if (error) throw error;
    
        // TODO: Integrate with virus scanning service
        // Options for production:
        // 1. VirusTotal API (https://www.virustotal.com/gui/home/upload)
        // 2. ClamAV REST API (open-source)
        // 3. AWS GuardDuty Malware Protection
        // 4. Google Cloud Security Command Center
    
        // For now, perform basic security checks
        const fileBuffer = await data.arrayBuffer();
        const bytes = new Uint8Array(fileBuffer);
    
        // Check for executable file signatures
        const suspiciousPatterns = [
          { pattern: [0x4D, 0x5A], name: 'Windows Executable (MZ)' }, // EXE
          { pattern: [0x7F, 0x45, 0x4C, 0x46], name: 'Linux Executable (ELF)' },
          { pattern: [0x50, 0x4B, 0x03, 0x04], name: 'ZIP Archive' }, // Could contain malware
          { pattern: [0x52, 0x61, 0x72, 0x21], name: 'RAR Archive' },
        ];
    
        for (const { pattern, name } of suspiciousPatterns) {
          if (bytes.length >= pattern.length) {
            const matches = pattern.every((byte, i) => bytes[i] === byte);
            if (matches) {
              // Delete the file
              await supabase.storage.from(bucket).remove([filePath]);
              
              // Log security incident
              await query(/* INSERT INTO security_incidents - TODO: Convert this manually */) || 'unknown',
              });
    
              return new Response(
                JSON.stringify({
                  success: false,
                  error: 'File failed security scan: Suspicious file type detected',
                }),
                {
                  headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
                  status: 403,
                }
              );
            }
          }
        }
    
        return new Response(
          JSON.stringify({
            success: true,
            message: 'File passed security scan',
          }),
          {
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
          }
        );
      } catch (error) {
        return new Response(
          JSON.stringify({ error: 'File scan failed' }),
          {
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
            status: 500,
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
