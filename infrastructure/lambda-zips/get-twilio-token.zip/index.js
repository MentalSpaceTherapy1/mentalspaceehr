/**
 * get-twilio-token Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    const twilioAccountSid = process.env.TWILIO_ACCOUNT_SID
    const twilioApiKey = process.env.TWILIO_API_KEY
    const twilioApiSecret = process.env.TWILIO_API_SECRET
    
    serve(async (req) => {
      // Handle CORS preflight
      )
      }
    
      try {
        if (req.method !== 'POST') {
          return new Response(
            JSON.stringify({ error: 'Method not allowed' }),
            { status: 405, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
          )
        }
    
        const { identity, room_name } = await req.json()
    
        if (!identity || !room_name) {
          return new Response(
            JSON.stringify({ error: 'Missing identity or room_name' }),
            { status: 400, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
          )
        }
    
        if (!twilioAccountSid || !twilioApiKey || !twilioApiSecret) {
          console.error('Missing Twilio credentials')
          return new Response(
            JSON.stringify({ error: 'Server configuration error' }),
            { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
          )
        }
    
        // Generate Twilio Access Token
        const token = await generateToken(identity, room_name)
    
        return new Response(
          JSON.stringify({ token }),
          { headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
        )
      } catch (error) {
        console.error('Error generating token:', error)
        return new Response(
          JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
          { status: 500, headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
        )
      }
    })
    
    async function generateToken(identity: string, roomName: string): Promise<string> {
      const now = Math.floor(Date.now() / 1000)
      const exp = now + 3600 // 1 hour expiration
    
      const videoGrant = {
        room: roomName
      }
    
      const payload = {
        iss: twilioApiKey,
        sub: twilioAccountSid,
        exp: exp,
        jti: `${twilioApiKey}-${now}`,
        grants: {
          identity: identity,
          video: videoGrant
        }
      }
    
      // Use jose library for JWT creation
      const jose = await import('https://deno.land/x/jose@v4.14.4/index.ts')
      const secret = new TextEncoder().encode(twilioApiSecret)
      
      const jwt = await new jose.SignJWT(payload)
        .setProtectedHeader({ alg: 'HS256', typ: 'JWT', cty: 'twilio-fpa;v=1' })
        .sign(secret)
    
      return jwt
    }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
