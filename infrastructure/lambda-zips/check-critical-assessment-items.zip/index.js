/**
 * check-critical-assessment-items Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    interface CheckCriticalItemsRequest {
      administrationId: string;
    }
    
    serve(async (req) => {
      );
      }
    
      try {
        // Using direct database connection
    const { administrationId }: CheckCriticalItemsRequest = await req.json();
    
        // Fetch administration with assessment details
        const { data: administration, error: adminError } = await supabase
          .from("assessment_administrations")
          .select(`
            *,
            assessment:clinical_assessments(*)
          `)
          .eq("id", administrationId)
          .single();
    
        if (adminError) throw adminError;
    
        const assessment = administration.assessment;
        const criticalItems = assessment.critical_items || [];
    
        if (criticalItems.length === 0) {
          return new Response(
            JSON.stringify({ success: true, alertsCreated: 0 }),
            { headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
          );
        }
    
        const responses = administration.responses || {};
        const alerts = [];
    
        // Check each critical item
        for (const criticalItem of criticalItems) {
          const { itemId, threshold, action, notifyRoles, severity } = criticalItem;
          const response = responses[itemId];
    
          if (response === undefined) continue;
    
          let isTriggered = false;
    
          // Check if response exceeds threshold
          if (typeof response === "number" && typeof threshold === "number") {
            isTriggered = response >= threshold;
          } else if (response === threshold) {
            isTriggered = true;
          }
    
          if (isTriggered) {
            // Find item text from assessment items
            const assessmentItem = assessment.items?.find((i: any) => i.itemId === itemId);
            const itemText = assessmentItem?.itemText || itemId;
    
            alerts.push({
              administration_id: administrationId,
              assessment_id: assessment.id,
              client_id: administration.client_id,
              critical_item_id: itemId,
              item_text: itemText,
              response_value: response,
              severity: severity || "High",
              action_required: action,
              alert_status: "Active",
            });
          }
        }
    
        // Insert alerts
        if (alerts.length > 0) {
          const { error: insertError } = await supabase
            .from("assessment_critical_alerts")
            .insert(alerts);
    
          if (insertError) throw insertError;
    
          // Get clinician info for notifications
          const { data: client } = await supabase
            .from("clients")
            .select("primary_therapist_id, psychiatrist_id, case_manager_id")
            .eq("id", administration.client_id)
            .single();
    
          // Notify relevant users
          const usersToNotify = [
            client?.primary_therapist_id,
            client?.psychiatrist_id,
            client?.case_manager_id,
          ].filter(Boolean);
    
          // TODO: Send notifications (email, dashboard alerts)
        }
    
        return new Response(
          JSON.stringify({
            success: true,
            alertsCreated: alerts.length,
          }),
          {
            headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
            status: 200,
          }
        );
      } catch (error: any) {
        return new Response(
          JSON.stringify({ error: 'Failed to check critical items' }),
          {
            headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
            status: 500,
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
