/**
 * integration-health-check Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    interface HealthCheckResult {
      service: string;
      status: 'healthy' | 'degraded' | 'down';
      response_time_ms: number;
      error_message?: string;
      metadata?: any;
    }
    
    
      );
      }
    
      try {
        console.log('Starting integration health checks...');
        
        // Using direct database connection
    const results: HealthCheckResult[] = [];
    
        // 1. Check Supabase Database Connection
        console.log('Checking database connection...');
        const dbStart = Date.now();
        try {
          const { data, error } = await supabase
            .from('profiles')
            .select('count')
            .limit(1)
            .single();
          
          if (error && error.code !== 'PGRST116') throw error;
          
          results.push({
            service: 'supabase_database',
            status: 'healthy',
            response_time_ms: Date.now() - dbStart,
            metadata: { check: 'profiles_query' }
          });
          console.log('✓ Database connection healthy');
        } catch (error: any) {
          results.push({
            service: 'supabase_database',
            status: 'down',
            response_time_ms: Date.now() - dbStart,
            error_message: error?.message || 'Unknown error'
          });
          console.error('✗ Database connection failed:', error?.message);
        }
    
        // 2. Check Authentication Service
        console.log('Checking auth service...');
        const authStart = Date.now();
        try {
          const { data: { users }, error } = await supabase.auth.admin.listUsers({
            page: 1,
            perPage: 1
          });
          
          if (error) throw error;
          
          results.push({
            service: 'supabase_auth',
            status: 'healthy',
            response_time_ms: Date.now() - authStart,
            metadata: { users_count: users.length }
          });
          console.log('✓ Auth service healthy');
        } catch (error: any) {
          results.push({
            service: 'supabase_auth',
            status: 'down',
            response_time_ms: Date.now() - authStart,
            error_message: error?.message || 'Unknown error'
          });
          console.error('✗ Auth service failed:', error?.message);
        }
    
        // 3. Check Storage Service
        console.log('Checking storage service...');
        const storageStart = Date.now();
        try {
          const { data, error } = await supabase.storage.listBuckets();
          
          if (error) throw error;
          
          results.push({
            service: 'supabase_storage',
            status: 'healthy',
            response_time_ms: Date.now() - storageStart,
            metadata: { buckets_count: data.length }
          });
          console.log('✓ Storage service healthy');
        } catch (error: any) {
          results.push({
            service: 'supabase_storage',
            status: 'down',
            response_time_ms: Date.now() - storageStart,
            error_message: error?.message || 'Unknown error'
          });
          console.error('✗ Storage service failed:', error?.message);
        }
    
        // 4. Check Critical Tables Accessibility
        console.log('Checking critical tables...');
        const tablesStart = Date.now();
        const criticalTables = [
          'clients',
          'appointments',
          'clinical_notes',
          'profiles',
          'user_roles'
        ];
        
        let tablesHealthy = true;
        const tableResults: any = {};
        
        for (const table of criticalTables) {
          try {
            const { error } = await supabase
              .from(table)
              .select('*')
              .limit(1);
            
            if (error) {
              tablesHealthy = false;
              tableResults[table] = 'error: ' + error.message;
            } else {
              tableResults[table] = 'accessible';
            }
          } catch (error: any) {
            tablesHealthy = false;
            tableResults[table] = 'error: ' + (error?.message || 'Unknown error');
          }
        }
        
        results.push({
          service: 'critical_tables',
          status: tablesHealthy ? 'healthy' : 'degraded',
          response_time_ms: Date.now() - tablesStart,
          metadata: tableResults
        });
        console.log(tablesHealthy ? '✓ Critical tables healthy' : '⚠ Some critical tables have issues');
    
        // 5. Check RLS Policies Enforcement
        console.log('Checking RLS enforcement...');
        const rlsStart = Date.now();
        try {
          // Try to access data without proper auth (should fail)
          const anonSupabase = createClient(
            process.env.SUPABASE_URL!,
            process.env.SUPABASE_ANON_KEY!
          );
          
          const { data, error } = await anonSupabase
            .from('clients')
            .select('*')
            .limit(1);
          
          // If we get data without auth, RLS is not working
          const rlsWorking = (error?.message?.includes('permission denied') || 
                              error?.code === 'PGRST301' ||
                              data === null || 
                              (Array.isArray(data) && data.length === 0));
          
          results.push({
            service: 'rls_policies',
            status: rlsWorking ? 'healthy' : 'down',
            response_time_ms: Date.now() - rlsStart,
            metadata: { 
              check: 'unauthorized_access_blocked',
              working: rlsWorking
            }
          });
          console.log(rlsWorking ? '✓ RLS policies enforced' : '✗ RLS policies NOT enforced');
        } catch (error: any) {
          results.push({
            service: 'rls_policies',
            status: 'degraded',
            response_time_ms: Date.now() - rlsStart,
            error_message: error?.message || 'Unknown error'
          });
          console.error('⚠ RLS check error:', error?.message);
        }
    
        // 6. Check Edge Functions Health
        console.log('Checking edge functions...');
        const functionsStart = Date.now();
        try {
          // Check if health-check function responds
          const { data, error } = await supabase.functions.invoke('health-check', {
            body: { check: 'integration-health' }
          });
          
          results.push({
            service: 'edge_functions',
            status: error ? 'degraded' : 'healthy',
            response_time_ms: Date.now() - functionsStart,
            metadata: { 
              health_check_function: error ? 'failed' : 'working'
            }
          });
          console.log(error ? '⚠ Edge functions degraded' : '✓ Edge functions healthy');
        } catch (error: any) {
          results.push({
            service: 'edge_functions',
            status: 'degraded',
            response_time_ms: Date.now() - functionsStart,
            error_message: error?.message || 'Unknown error'
          });
          console.error('⚠ Edge functions check error:', error?.message);
        }
    
        // 7. Check Database Performance
        console.log('Checking database performance...');
        const perfStart = Date.now();
        try {
          // Run a complex query to test performance
          const { data, error } = await supabase
            .from('appointments')
            .select(`
              *,
              clients(first_name, last_name),
              profiles!appointments_clinician_id_fkey(first_name, last_name)
            `)
            .limit(10);
          
          const queryTime = Date.now() - perfStart;
          const status = queryTime < 500 ? 'healthy' : 
                         queryTime < 2000 ? 'degraded' : 'down';
          
          results.push({
            service: 'database_performance',
            status,
            response_time_ms: queryTime,
            metadata: { 
              query_type: 'complex_join',
              records_fetched: data?.length || 0,
              threshold_ms: 500
            }
          });
          console.log(`${status === 'healthy' ? '✓' : '⚠'} Database performance: ${queryTime}ms`);
        } catch (error: any) {
          results.push({
            service: 'database_performance',
            status: 'down',
            response_time_ms: Date.now() - perfStart,
            error_message: error?.message || 'Unknown error'
          });
          console.error('✗ Database performance check failed:', error?.message);
        }
    
        // Store results in database
        console.log('Storing health check results...');
        const timestamp = new Date().toISOString();
        
        for (const result of results) {
          await query(/* INSERT INTO integration_health_logs - TODO: Convert this manually */);
        }
    
        // Check if any critical services are down
        const criticalDown = results.filter(r => 
          ['supabase_database', 'supabase_auth', 'rls_policies'].includes(r.service) &&
          r.status === 'down'
        );
    
        if (criticalDown.length > 0) {
          console.log('🚨 CRITICAL: Some services are down!');
          
          // Get administrators to notify
          const { data: adminRoles } = await supabase
            .from('user_roles')
            .select('user_id')
            .eq('role', 'administrator');
    
          const adminIds = adminRoles?.map(r => r.user_id) || [];
    
          if (adminIds.length > 0) {
            await query(/* INSERT INTO notification_logs - TODO: Convert this manually */).join('\n')}\n\nImmediate attention required!`,
              priority: 'urgent',
              sent_via: ['email', 'in_app']
            });
            console.log(`Alert sent to ${adminIds.length} administrators`);
          }
        }
    
        // Calculate overall health
        const healthyCount = results.filter(r => r.status === 'healthy').length;
        const degradedCount = results.filter(r => r.status === 'degraded').length;
        const downCount = results.filter(r => r.status === 'down').length;
        
        const overallStatus = downCount > 0 ? 'down' :
                             degradedCount > 0 ? 'degraded' : 'healthy';
    
        console.log(`Health check complete: ${healthyCount} healthy, ${degradedCount} degraded, ${downCount} down`);
    
        return new Response(
          JSON.stringify({
            success: true,
            timestamp,
            overall_status: overallStatus,
            summary: {
              total_checks: results.length,
              healthy: healthyCount,
              degraded: degradedCount,
              down: downCount
            },
            results
          }),
          { 
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
          }
        );
      } catch (error) {
        console.error('Integration health check error:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        
        return new Response(
          JSON.stringify({ 
            error: errorMessage,
            timestamp: new Date().toISOString()
          }),
          { 
            status: 500,
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
