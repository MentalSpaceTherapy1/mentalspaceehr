/**
 * create-portal-user Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    const supabaseUrl = process.env.SUPABASE_URL!;
    const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
    
    // Validation schema
    const requestSchema = z.object({
      clientId: z.string().uuid('Invalid client ID format'),
      email: z.string().email('Invalid email format').max(255),
      clientName: z.string().min(1).max(200),
    });
    
    const handler = async (req: Request): Promise<Response> => {
      );
      }
    
      try {
        const rawBody = await req.json();
        
        // Validate input
        const validation = requestSchema.safeParse(rawBody);
        if (!validation.success) {
          return new Response(
            JSON.stringify({ 
              error: 'Invalid input',
              details: validation.error.issues 
            }),
            {
              status: 400,
              headers: { "Content-Type": "application/json", ...CORS_HEADERS },
            }
          );
        }
    
        const { clientId, email, clientName } = validation.data;
    
        // Create admin client with service role key
        const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
          auth: {
            autoRefreshToken: false,
            persistSession: false
          }
        });
    
        // Check if user already exists
        const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
        const existingUser = existingUsers?.users.find(u => u.email === email);
    
        let userId: string;
        let isNewUser = false;
    
        if (existingUser) {
          userId = existingUser.id;
          
          // Update metadata to mark as portal user
          await supabaseAdmin.auth.admin.updateUserById(userId, {
            user_metadata: {
              ...existingUser.user_metadata,
              client_id: clientId,
              is_portal_user: true,
            },
          });
        } else {
          // Generate temporary password
          const tempPassword = `Temp${Math.random().toString(36).slice(-8)}!1A`;
    
          // Create auth user
          const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
            email,
            password: tempPassword,
            email_confirm: false,
            user_metadata: {
              client_id: clientId,
              is_portal_user: true,
            },
          });
    
          if (authError) throw authError;
    
          userId = authData.user.id;
          isNewUser = true;
        }
    
        // Assign client_user role (check if it exists first)
        const { data: existingRole } = await supabaseAdmin
          .from('user_roles')
          .select('*')
          .eq('user_id', userId)
          .eq('role', 'client_user')
          .single();
    
        if (!existingRole) {
          const { error: roleError } = await supabaseAdmin
            .from('user_roles')
            .insert({ user_id: userId, role: 'client_user' });
    
          if (roleError) throw roleError;
        }
    
        // Update client with portal_user_id
        const { error: updateError } = await supabaseAdmin
          .from('clients')
          .update({ 
            portal_user_id: userId, 
            portal_enabled: true,
            email: email
          })
          .eq('id', clientId);
    
        if (updateError) throw updateError;
    
        // SECURITY: Never return passwords in API response
        // Password should only be sent via email
        return new Response(
          JSON.stringify({ 
            success: true, 
            userId: userId,
            isNewUser: isNewUser,
            message: isNewUser 
              ? 'Portal user created successfully. Credentials sent via email.'
              : 'Portal access enabled for existing user.'
          }), 
          {
            status: 200,
            headers: { "Content-Type": "application/json", ...CORS_HEADERS },
          }
        );
      } catch (error: any) {
        return new Response(
          JSON.stringify({ error: 'Failed to create portal user' }),
          {
            status: 500,
            headers: { "Content-Type": "application/json", ...CORS_HEADERS },
          }
        );
      }
    };
    
    serve(handler);

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
