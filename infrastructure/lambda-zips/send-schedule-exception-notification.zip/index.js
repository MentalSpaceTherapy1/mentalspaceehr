/**
 * send-schedule-exception-notification Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    interface NotificationRequest {
      exceptionId: string;
      clinicianId: string;
      exceptionType: string;
      startDate: string;
      endDate: string;
      reason: string;
    }
    
    const handler = async (req: Request): Promise<Response> => {
      );
      }
    
      try {
        // Using direct database connection
    const { exceptionId, clinicianId, exceptionType, startDate, endDate, reason }: NotificationRequest = await req.json();
    
        console.log("Processing schedule exception notification:", { exceptionId, clinicianId });
    
        // Get clinician details
        const { data: clinician, error: clinicianError } = await supabase
          .from("profiles")
          .select("first_name, last_name, email")
          .eq("id", clinicianId)
          .single();
    
        if (clinicianError) {
          console.error("Error fetching clinician:", clinicianError);
          throw clinicianError;
        }
    
        // Get admin emails for approval notifications
        const { data: adminRoles, error: adminError } = await supabase
          .from("user_roles")
          .select("user_id")
          .eq("role", "administrator");
    
        if (adminError) {
          console.error("Error fetching admins:", adminError);
          throw adminError;
        }
    
        const adminIds = adminRoles?.map(r => r.user_id) || [];
        
        const { data: admins, error: adminsError } = await supabase
          .from("profiles")
          .select("email, first_name, last_name")
          .in("id", adminIds);
    
        if (adminsError) {
          console.error("Error fetching admin profiles:", adminsError);
          throw adminsError;
        }
    
        // Log notification (email sending would require Resend API key)
        console.log("Would send notifications to admins:", admins?.map(a => a.email));
        console.log("Exception details:", {
          clinician: `${clinician.first_name} ${clinician.last_name}`,
          type: exceptionType,
          dates: `${startDate} to ${endDate}`,
          reason
        });
    
        // Log notification in database
        await query(/* INSERT INTO notification_logs - TODO: Convert this manually */).toISOString(),
          status: "Sent",
          related_record_id: exceptionId,
          related_record_type: "schedule_exception"
        });
    
        return new Response(
          JSON.stringify({ 
            success: true, 
            message: "Notification logged successfully",
            adminCount: admins?.length || 0
          }),
          { 
            status: 200, 
            headers: { ...CORS_HEADERS, "Content-Type": "application/json" } 
          }
        );
      } catch (error: any) {
        console.error("Error processing schedule exception notification:", error);
        return new Response(
          JSON.stringify({ error: error.message }),
          { 
            status: 500, 
            headers: { ...CORS_HEADERS, "Content-Type": "application/json" } 
          }
        );
      }
    };
    
    serve(handler);

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
