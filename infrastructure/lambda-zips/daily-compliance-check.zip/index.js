/**
 * daily-compliance-check Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    interface ComplianceViolation {
      type: string;
      severity: 'low' | 'medium' | 'high' | 'critical';
      count?: number;
      description: string;
      data?: any;
    }
    
    
      // Handle CORS preflight
      );
      }
    
      try {
        console.log('Starting daily compliance check...');
        
        // Using direct database connection
    const violations: ComplianceViolation[] = [];
    
        // Check 1: Unsigned associate notes >7 days old
        console.log('Checking for unsigned associate notes...');
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
        const { data: unsignedNotes } = await supabase
          .from('clinical_notes')
          .select('id, client_id, clinician_id, created_date')
          .eq('requires_cosignature', true)
          .is('cosigned_by', null)
          .lt('created_date', sevenDaysAgo.toISOString());
    
        if (unsignedNotes && unsignedNotes.length > 0) {
          console.log(`Found ${unsignedNotes.length} unsigned notes`);
          violations.push({
            type: 'unsigned_associate_notes',
            severity: 'high',
            count: unsignedNotes.length,
            description: `${unsignedNotes.length} associate notes require co-signature (>7 days old)`,
            data: unsignedNotes.slice(0, 10) // Include first 10 for details
          });
        }
    
        // Check 2: Excessive PHI access in last hour
        console.log('Checking for excessive PHI access...');
        const { data: excessiveAccess } = await supabase
          .rpc('check_excessive_phi_access', { hours: 1, threshold: 50 });
    
        if (excessiveAccess && excessiveAccess.length > 0) {
          console.log(`Found ${excessiveAccess.length} users with excessive PHI access`);
          violations.push({
            type: 'excessive_phi_access',
            severity: 'critical',
            count: excessiveAccess.length,
            description: `${excessiveAccess.length} users exceeded PHI access threshold (50 in 1 hour)`,
            data: excessiveAccess
          });
        }
    
        // Check 3: Orphaned appointments (completed but no note)
        console.log('Checking for orphaned appointments...');
        const twoDaysAgo = new Date();
        twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
    
        const { data: orphanedAppts } = await supabase
          .from('appointments')
          .select('id, client_id, clinician_id, appointment_date, appointment_type')
          .eq('status', 'Completed')
          .lt('appointment_date', twoDaysAgo.toISOString().split('T')[0])
          .is('note_id', null)
          .limit(100);
    
        if (orphanedAppts && orphanedAppts.length > 0) {
          console.log(`Found ${orphanedAppts.length} orphaned appointments`);
          violations.push({
            type: 'orphaned_appointments',
            severity: 'medium',
            count: orphanedAppts.length,
            description: `${orphanedAppts.length} completed appointments missing clinical notes (>48 hours)`,
            data: orphanedAppts.slice(0, 10)
          });
        }
    
        // Check 4: Stale user accounts (no login >90 days)
        console.log('Checking for stale user accounts...');
        const ninetyDaysAgo = new Date();
        ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    
        const { data: staleAccounts } = await supabase
          .from('profiles')
          .select('id, email, last_login_date, is_active')
          .eq('is_active', true)
          .lt('last_login_date', ninetyDaysAgo.toISOString())
          .limit(50);
    
        if (staleAccounts && staleAccounts.length > 0) {
          console.log(`Found ${staleAccounts.length} stale accounts`);
          violations.push({
            type: 'stale_user_accounts',
            severity: 'medium',
            count: staleAccounts.length,
            description: `${staleAccounts.length} active accounts with no login in 90+ days`,
            data: staleAccounts.map(a => ({ id: a.id, email: a.email, lastLogin: a.last_login_date }))
          });
        }
    
        // Check 5: Users without roles
        console.log('Checking for users without roles...');
        const { data: usersWithoutRoles } = await supabase
          .from('profiles')
          .select(`
            id,
            email,
            is_active,
            user_roles!left(role)
          `)
          .eq('is_active', true)
          .is('user_roles.role', null);
    
        if (usersWithoutRoles && usersWithoutRoles.length > 0) {
          console.log(`Found ${usersWithoutRoles.length} users without roles`);
          violations.push({
            type: 'users_without_roles',
            severity: 'critical',
            count: usersWithoutRoles.length,
            description: `${usersWithoutRoles.length} active users have no assigned roles`,
            data: usersWithoutRoles.map(u => ({ id: u.id, email: u.email }))
          });
        }
    
        console.log(`Compliance check complete. Found ${violations.length} violation types.`);
    
        // Send notifications if violations found
        if (violations.length > 0) {
          console.log('Sending compliance alert notifications...');
          
          // Get all administrators
          const { data: adminRoles } = await supabase
            .from('user_roles')
            .select('user_id')
            .eq('role', 'administrator');
    
          const adminIds = adminRoles?.map(r => r.user_id) || [];
    
          if (adminIds.length > 0) {
            // Create summary message
            const criticalCount = violations.filter(v => v.severity === 'critical').length;
            const highCount = violations.filter(v => v.severity === 'high').length;
            
            const summary = `Daily Compliance Check Results:\n\n` +
              `Critical Issues: ${criticalCount}\n` +
              `High Priority Issues: ${highCount}\n` +
              `Total Issues: ${violations.length}\n\n` +
              violations.map(v => `- ${v.description}`).join('\n');
    
            // Insert notification
            await query(/* INSERT INTO notification_logs - TODO: Convert this manually */);
    
            console.log(`Notification sent to ${adminIds.length} administrators`);
          }
        } else {
          console.log('No compliance violations found.');
        }
    
        return new Response(
          JSON.stringify({
            success: true,
            violations,
            timestamp: new Date().toISOString(),
            summary: {
              total: violations.length,
              critical: violations.filter(v => v.severity === 'critical').length,
              high: violations.filter(v => v.severity === 'high').length,
              medium: violations.filter(v => v.severity === 'medium').length,
              low: violations.filter(v => v.severity === 'low').length
            }
          }),
          { 
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
          }
        );
      } catch (error) {
        console.error('Compliance check error:', error);
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        return new Response(
          JSON.stringify({ 
            error: errorMessage,
            timestamp: new Date().toISOString()
          }),
          { 
            status: 500,
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' }
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
