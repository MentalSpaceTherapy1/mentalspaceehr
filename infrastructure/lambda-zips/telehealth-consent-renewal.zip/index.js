/**
 * telehealth-consent-renewal Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    const resend = new Resend(process.env.RESEND_API_KEY);
    
    serve(async (req) => {
      );
      }
    
      try {
        const supabaseUrl = process.env.SUPABASE_URL!;
        const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
        const resendApiKey = process.env.RESEND_API_KEY;
    
        // Using direct database connection
    // Find consents expiring in 30 days that haven't been notified
        const thirtyDaysFromNow = new Date();
        thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
        const targetDate = thirtyDaysFromNow.toISOString().split('T')[0];
    
        const { data: expiringConsents, error: queryError } = await supabase
          .from('telehealth_consents')
          .select(`
            *,
            clients:client_id (
              id,
              first_name,
              last_name,
              email
            ),
            profiles:clinician_id (
              id,
              email
            )
          `)
          .eq('consent_given', true)
          .eq('consent_revoked', false)
          .eq('renewal_notified', false)
          .eq('expiration_date', targetDate);
    
        if (queryError) throw queryError;
    
        if (!expiringConsents || expiringConsents.length === 0) {
          return new Response(
            JSON.stringify({ message: 'No consents require renewal notification' }),
            { headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
          );
        }
    
        const results = [];
    
        // Send renewal notifications
        for (const consent of expiringConsents) {
          try {
            const clientEmail = consent.clients?.email;
            const clinicianEmail = consent.profiles?.email;
            const clientName = `${consent.clients?.first_name} ${consent.clients?.last_name}`;
            const clinicianName = `${consent.profiles?.first_name || ''} ${consent.profiles?.last_name || ''}`.trim();
            
            if (!clientEmail) {
              continue;
            }
    
            // Send email to client
            const appUrl = process.env.APP_URL || 'https://your-app-url.com';
            
            await resend.emails.send({
              from: 'MentalSpace <noreply@resend.dev>',
              to: [clientEmail],
              subject: 'Telehealth Consent Renewal Required',
              html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                  <h2 style="color: #333;">Telehealth Consent Renewal</h2>
                  <p>Hi ${consent.clients.first_name},</p>
                  <p>Your telehealth consent is expiring on <strong>${new Date(consent.expiration_date).toLocaleDateString()}</strong> (in 30 days).</p>
                  <p>To continue receiving telehealth services, please complete the renewal form before your next session.</p>
                  <p style="margin: 30px 0;">
                    <a href="${appUrl}/telehealth/consent-renewal/${consent.id}" 
                       style="background-color: #0066cc; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">
                      Renew Consent Now
                    </a>
                  </p>
                  <p style="color: #666; font-size: 14px;">If you have any questions, please contact your clinician.</p>
                  <p>Best regards,<br>Your MentalSpace Team</p>
                </div>
              `,
            });
    
            // Send notification to clinician
            if (clinicianEmail) {
              await resend.emails.send({
                from: 'MentalSpace <noreply@resend.dev>',
                to: [clinicianEmail],
                subject: `Client Consent Expiring: ${clientName}`,
                html: `
                  <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #333;">Telehealth Consent Expiration Notice</h2>
                    <p>Hi ${clinicianName},</p>
                    <p>This is a reminder that <strong>${clientName}</strong>'s telehealth consent will expire on <strong>${new Date(consent.expiration_date).toLocaleDateString()}</strong>.</p>
                    <p>A renewal notification has been sent to the client. Please follow up if they have not renewed the consent before their next scheduled telehealth session.</p>
                    <p style="color: #666; font-size: 14px;">Client Email: ${clientEmail}</p>
                  </div>
                `,
              });
            }
    
            // Mark as notified
            await supabase
              .from('telehealth_consents')
              .update({
                renewal_notified: true,
                renewal_notification_date: new Date().toISOString(),
              })
              .eq('id', consent.id);
    
            results.push({
              consentId: consent.id,
              clientName,
              status: 'notified',
            });
          } catch (error: any) {
            results.push({
              consentId: consent.id,
              status: 'error',
              error: error.message,
            });
          }
        }
    
        return new Response(
          JSON.stringify({
            message: `Processed ${results.length} renewal notifications`,
            results,
          }),
          { headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } }
        );
      } catch (error: any) {
        return new Response(
          JSON.stringify({ error: 'Renewal check failed' }),
          {
            status: 500,
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
