/**
 * send-waitlist-email Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    interface Payload {
      waitlist_id: string;
      custom_message?: string;
    }
    
    serve(async (req) => {
      );
      }
    
      try {
        const { waitlist_id, custom_message }: Payload = await req.json();
        if (!waitlist_id) {
          return new Response(
            JSON.stringify({ success: false, message: "waitlist_id is required" }),
            { headers: { ...CORS_HEADERS, "Content-Type": "application/json" }, status: 400 }
          );
        }
    
        const supabaseUrl = process.env.SUPABASE_URL!;
        const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
        const resendApiKey = process.env.RESEND_API_KEY!;
    
        // Using direct database connection
    const resend = new Resend(resendApiKey);
    
        // Fetch waitlist entry
        const { data: entry, error: entryError } = await supabase
          .from("appointment_waitlist")
          .select("id, client_id, clinician_id, appointment_type, preferred_days, preferred_times")
          .eq("id", waitlist_id)
          .maybeSingle();
    
        if (entryError) throw entryError;
        if (!entry) {
          return new Response(
            JSON.stringify({ success: false, message: "Waitlist entry not found" }),
            { headers: { ...CORS_HEADERS, "Content-Type": "application/json" }, status: 404 }
          );
        }
    
        // Fetch client and clinician
        const [{ data: client }, { data: clinician }] = await Promise.all([
          supabase.from("clients").select("first_name, last_name, email, primary_phone").eq("id", entry.client_id).maybeSingle(),
          supabase.from("profiles").select("first_name, last_name").eq("id", entry.clinician_id).maybeSingle(),
        ]);
    
        if (!client?.email) {
          return new Response(
            JSON.stringify({ success: false, message: "Client has no email on file" }),
            { headers: { ...CORS_HEADERS, "Content-Type": "application/json" }, status: 200 }
          );
        }
    
        const preferredDays = (entry.preferred_days || []) as string[];
        const preferredTimes = (entry.preferred_times || []) as string[];
    
        const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        const preferredDaysText = preferredDays.length
          ? preferredDays.map((d) => dayNames[parseInt(d)]).join(", ")
          : "Any";
        const preferredTimesText = preferredTimes.length ? preferredTimes.join(", ") : "Any";
    
        const html = `
          <div>
            <h2 style="margin:0 0 12px 0">Appointment Availability</h2>
            <p>Hi ${client.first_name},</p>
            <p>${custom_message || "A time may be available that matches your preferences. Please confirm if you'd like to book this appointment."}</p>
            <div style="background:#f5f7fb;padding:12px;border-radius:8px;margin:16px 0">
              <p style="margin:4px 0"><strong>Type:</strong> ${entry.appointment_type}</p>
              <p style="margin:4px 0"><strong>Preferred Days:</strong> ${preferredDaysText}</p>
              <p style="margin:4px 0"><strong>Preferred Times:</strong> ${preferredTimesText}</p>
              <p style="margin:4px 0"><strong>Clinician:</strong> ${clinician?.first_name ?? ""} ${clinician?.last_name ?? ""}</p>
            </div>
            <p>Reply to this email to confirm, or call our office to schedule.</p>
            <p style="margin-top:16px">Best regards,<br/>MentalSpace Team</p>
          </div>
        `;
    
        const emailResult = await resend.emails.send({
          from: "MentalSpace <onboarding@resend.dev>",
          to: [client.email],
          subject: "Waitlist Update: Appointment Availability",
          html,
        });
    
        // Update entry as notified
        await supabase
          .from("appointment_waitlist")
          .update({ notified: true, notified_date: new Date().toISOString() })
          .eq("id", waitlist_id);
    
        return new Response(
          JSON.stringify({ success: true }),
          { headers: { ...CORS_HEADERS, "Content-Type": "application/json" }, status: 200 }
        );
      } catch (error) {
        return new Response(
          JSON.stringify({ success: false, error: 'Email failed' }),
          { headers: { ...CORS_HEADERS, "Content-Type": "application/json" }, status: 500 }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
