/**
 * generate-note-from-transcript Lambda Function
 * Converted from Supabase Edge Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

// Helper to execute database query
async function query(sql, params = []) {
  const client = await getDbClient();
  return await client.query(sql, params);
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const headers = event.headers || {};

    // Get user from Cognito JWT (passed by API Gateway authorizer)
    const userId = event.requestContext?.authorizer?.jwt?.claims?.sub || null;

    import "https://deno.land/x/xhr@0.1.0/mod.ts";
    serve(async (req) => {
      );
      }
    
      try {
        const { transcript, clientId, clinicianId, appointmentId, sessionId } = await req.json();
    
        if (!transcript || !clientId || !clinicianId) {
          throw new Error('Missing required fields');
        }
    
        const LOVABLE_API_KEY = process.env.LOVABLE_API_KEY;
        if (!LOVABLE_API_KEY) {
          throw new Error('LOVABLE_API_KEY is not configured');
        }
    
        // Generate clinical note from transcript using Lovable AI
        const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${LOVABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash',
            messages: [
              {
                role: 'system',
                content: `You are a clinical documentation assistant. Generate a professional clinical note from the provided session transcript. Include:
    - Chief Complaint/Presenting Issue
    - Session Summary
    - Clinical Observations
    - Interventions Used
    - Client Progress
    - Treatment Plan Updates
    - Risk Assessment (if applicable)
    Format the note professionally and concisely.`
              },
              {
                role: 'user',
                content: `Generate a clinical note from this telehealth session:\n\n${transcript}`
              }
            ],
          }),
        });
    
        if (!response.ok) {
          const errorText = await response.text();
          console.error('AI API error:', response.status, errorText);
          throw new Error('Failed to generate clinical note');
        }
    
        const aiData = await response.json();
        const generatedNote = aiData.choices[0].message.content;
    
        // Create note in database
        const supabaseClient = createClient(
          process.env.SUPABASE_URL ?? '',
          process.env.SUPABASE_SERVICE_ROLE_KEY ?? ''
        );
    
        const { data: noteData, error: noteError } = await supabaseClient
          .from('chart_notes')
          .insert({
            client_id: clientId,
            clinician_id: clinicianId,
            appointment_id: appointmentId,
            session_date: new Date().toISOString().split('T')[0],
            note_type: 'Progress Note',
            content: generatedNote,
            status: 'Draft',
            ai_generated: true,
            telehealth_session_id: sessionId,
          })
          .select()
          .single();
    
        if (noteError) {
          console.error('Note creation error:', noteError);
          throw new Error('Failed to create note');
        }
    
        return new Response(
          JSON.stringify({ 
            noteId: noteData.id,
            content: generatedNote
          }),
          { 
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } 
          }
        );
    
      } catch (error) {
        console.error('Error:', error);
        return new Response(
          JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
          { 
            status: 500,
            headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' } 
          }
        );
      }

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
