const { Client } = require('pg');

exports.handler = async (event) => {
  const client = new Client({
    host: process.env.DATABASE_ENDPOINT,
    port: parseInt(process.env.DATABASE_PORT || '5432'),
    database: process.env.DATABASE_NAME,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    ssl: { rejectUnauthorized: false },
    connectionTimeoutMillis: 5000,
  });

  try {
    await client.connect();

    const table = event.pathParameters?.table;
    if (!table) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'Table name is required' })
      };
    }

    const params = event.queryStringParameters || {};
    let query = `SELECT * FROM ${table}`;
    const values = [];
    const conditions = [];
    let paramIndex = 1;

    for (const [key, value] of Object.entries(params)) {
      if (['select', 'order_by', 'order_dir', 'limit', 'offset'].includes(key)) continue;

      const match = key.match(/^(.+)_(eq|neq|gt|lt|gte|lte|in)$/);
      if (match) {
        const [, column, operator] = match;
        let parsedValue;
        try {
          parsedValue = JSON.parse(value);
        } catch {
          parsedValue = value;
        }

        switch (operator) {
          case 'eq':
            conditions.push(`${column} = $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'neq':
            conditions.push(`${column} != $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'gt':
            conditions.push(`${column} > $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'lt':
            conditions.push(`${column} < $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'gte':
            conditions.push(`${column} >= $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'lte':
            conditions.push(`${column} <= $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'in':
            if (Array.isArray(parsedValue)) {
              conditions.push(`${column} = ANY($${paramIndex})`);
              values.push(parsedValue);
              paramIndex++;
            }
            break;
        }
      }
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }

    if (params.order_by) {
      const orderDir = params.order_dir || 'asc';
      query += ` ORDER BY ${params.order_by} ${orderDir.toUpperCase()}`;
    }

    if (params.limit) {
      query += ` LIMIT ${parseInt(params.limit)}`;
    }

    if (params.offset) {
      query += ` OFFSET ${parseInt(params.offset)}`;
    }

    console.log('Executing query:', query, 'with values:', values);

    const result = await client.query(query, values);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      },
      body: JSON.stringify(result.rows),
    };

  } catch (error) {
    console.error('Query error:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: 'Database query failed',
        message: error.message,
      }),
    };
  } finally {
    await client.end();
  }
};
