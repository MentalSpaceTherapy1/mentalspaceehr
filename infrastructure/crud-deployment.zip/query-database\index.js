/**
 * Universal Query Database Lambda
 * Handles generic SELECT queries for any table
 * Route: GET /query/{table}
 */

const { Client } = require('pg');

// Get database credentials from environment
const getDbConfig = () => ({
  host: process.env.DATABASE_ENDPOINT,
  port: parseInt(process.env.DATABASE_PORT || '5432'),
  database: process.env.DATABASE_NAME,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASSWORD,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 5000,
  query_timeout: 30000,
});

exports.handler = async (event) => {
  console.log('Query Database Event:', JSON.stringify(event, null, 2));

  const client = new Client(getDbConfig());

  try {
    await client.connect();
    console.log('Connected to database');

    // Get table name from path
    const table = event.pathParameters?.table;

    if (!table) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Table name is required' }),
      };
    }

    // Get query parameters
    const params = event.queryStringParameters || {};

    // Build SELECT query
    let query = `SELECT * FROM ${table}`;
    const values = [];
    const conditions = [];
    let paramIndex = 1;

    // Handle filters (column_eq, column_neq, column_gt, column_lt, column_in)
    for (const [key, value] of Object.entries(params)) {
      if (key === 'select' || key === 'order_by' || key === 'order_dir' || key === 'limit' || key === 'offset') {
        continue;
      }

      // Parse filter type
      const match = key.match(/^(.+)_(eq|neq|gt|lt|gte|lte|in)$/);
      if (match) {
        const [, column, operator] = match;

        let parsedValue;
        try {
          parsedValue = JSON.parse(value);
        } catch {
          parsedValue = value;
        }

        switch (operator) {
          case 'eq':
            conditions.push(`${column} = $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'neq':
            conditions.push(`${column} != $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'gt':
            conditions.push(`${column} > $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'lt':
            conditions.push(`${column} < $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'gte':
            conditions.push(`${column} >= $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'lte':
            conditions.push(`${column} <= $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'in':
            if (Array.isArray(parsedValue)) {
              conditions.push(`${column} = ANY($${paramIndex})`);
              values.push(parsedValue);
              paramIndex++;
            }
            break;
        }
      }
    }

    // Add WHERE clause if conditions exist
    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }

    // Add ORDER BY
    if (params.order_by) {
      const orderDir = params.order_dir || 'asc';
      query += ` ORDER BY ${params.order_by} ${orderDir.toUpperCase()}`;
    }

    // Add LIMIT
    if (params.limit) {
      query += ` LIMIT ${parseInt(params.limit)}`;
    }

    // Add OFFSET
    if (params.offset) {
      query += ` OFFSET ${parseInt(params.offset)}`;
    }

    console.log('Executing query:', query);
    console.log('With values:', values);

    // Execute query
    const result = await client.query(query, values);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      },
      body: JSON.stringify(result.rows),
    };

  } catch (error) {
    console.error('Query error:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: 'Database query failed',
        message: error.message,
      }),
    };
  } finally {
    await client.end();
  }
};
