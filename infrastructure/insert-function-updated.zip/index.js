const { Client } = require('pg');

exports.handler = async (event) => {
  const client = new Client({
    host: process.env.DATABASE_ENDPOINT,
    port: parseInt(process.env.DATABASE_PORT || '5432'),
    database: process.env.DATABASE_NAME,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    ssl: { rejectUnauthorized: false },
    connectionTimeoutMillis: 5000,
  });

  try {
    await client.connect();

    const table = event.pathParameters?.table;
    if (!table) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        },
        body: JSON.stringify({ error: 'Table name is required' })
      };
    }

    const data = JSON.parse(event.body || '{}');

    const records = Array.isArray(data) ? data : [data];

    if (records.length === 0) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        },
        body: JSON.stringify({ error: 'No data provided' }),
      };
    }

    const columns = Object.keys(records[0]);
    const columnList = columns.join(', ');

    const valuePlaceholders = records.map((_, recordIndex) => {
      const placeholders = columns.map((_, colIndex) => {
        return `$${recordIndex * columns.length + colIndex + 1}`;
      }).join(', ');
      return `(${placeholders})`;
    }).join(', ');

    const query = `
      INSERT INTO ${table} (${columnList})
      VALUES ${valuePlaceholders}
      RETURNING *
    `;

    const values = records.flatMap(record => columns.map(col => record[col]));

    console.log('Executing query:', query);
    console.log('With values:', values);

    const result = await client.query(query, values);

    return {
      statusCode: 201,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      },
      body: JSON.stringify(result.rows),
    };

  } catch (error) {
    console.error('Insert error:', error);

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      },
      body: JSON.stringify({
        error: 'Database insert failed',
        message: error.message,
      }),
    };
  } finally {
    await client.end();
  }
};
