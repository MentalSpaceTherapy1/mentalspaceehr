/**
 * update-user-role Lambda Function - Update user's role in profiles table
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'PUT, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();

    // Parse request body
    const body = JSON.parse(event.body || '{}');
    const { user_id, role, assigned_by } = body;

    if (!user_id || !role) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'user_id and role are required' })
      };
    }

    // Valid roles
    const validRoles = ['administrator', 'supervisor', 'therapist', 'billing_staff', 'front_desk', 'associate_trainee', 'client_user'];
    if (!validRoles.includes(role)) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Invalid role' })
      };
    }

    // Update user's role in profiles table
    const result = await client.query(
      `UPDATE public.profiles
       SET role = $1, updated_at = NOW()
       WHERE id = $2
       RETURNING id, email, first_name, last_name, role`,
      [role, user_id]
    );

    if (result.rows.length === 0) {
      return {
        statusCode: 404,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'User not found' })
      };
    }

    // Log role assignment in audit_logs table (if it exists)
    try {
      await client.query(
        `INSERT INTO public.audit_logs (user_id, action, details, created_at)
         VALUES ($1, $2, $3, NOW())`,
        [assigned_by || user_id, 'role_assigned', JSON.stringify({ user_id, role, assigned_by })]
      );
    } catch (auditError) {
      console.log('[update-user-role] Audit log failed (table may not exist):', auditError.message);
    }

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        user: result.rows[0]
      })
    };

  } catch (error) {
    console.error('[update-user-role] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
