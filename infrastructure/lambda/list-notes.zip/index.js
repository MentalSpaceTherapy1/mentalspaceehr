/**
 * list-notes Lambda Function
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();
    const { client_id, clinician_id, note_type, limit = '50', offset = '0' } = event.queryStringParameters || {};

    let query = `
      SELECT
        n.*,
        c.first_name as client_first_name,
        c.last_name as client_last_name,
        p.first_name as clinician_first_name,
        p.last_name as clinician_last_name
      FROM public.clinical_notes n
      LEFT JOIN public.clients c ON n.client_id = c.id
      LEFT JOIN public.profiles p ON n.clinician_id = p.id
      WHERE 1=1
    `;

    const params = [];
    let paramCount = 0;

    if (client_id) {
      paramCount++;
      query += ` AND n.client_id = $${paramCount}`;
      params.push(client_id);
    }

    if (clinician_id) {
      paramCount++;
      query += ` AND n.clinician_id = $${paramCount}`;
      params.push(clinician_id);
    }

    if (note_type) {
      paramCount++;
      query += ` AND n.note_type = $${paramCount}`;
      params.push(note_type);
    }

    query += ` ORDER BY n.session_date DESC, n.created_at DESC`;
    query += ` LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    params.push(parseInt(limit), parseInt(offset));

    const result = await client.query(query, params);

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: result.rows })
    };

  } catch (error) {
    console.error('[list-notes] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
