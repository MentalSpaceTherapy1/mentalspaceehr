/**
 * create-user Lambda Function - Create new user in Cognito and profiles table
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');
const secretsManager = new AWS.SecretsManager({ region: 'us-east-1' });
const cognito = new AWS.CognitoIdentityServiceProvider({ region: 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;
  const secretArn = process.env.DB_SECRET_ARN || process.env.DATABASE_SECRET_ARN;
  const secretResponse = await secretsManager.getSecretValue({ SecretId: secretArn }).promise();
  const dbCredentials = JSON.parse(secretResponse.SecretString);
  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: dbCredentials.dbname || dbCredentials.database || 'mentalspaceehr',
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });
  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  try {
    const client = await getDbClient();

    // Parse request body
    const body = JSON.parse(event.body || '{}');
    const { email, password, profile } = body;

    if (!email || !password) {
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'email and password are required' })
      };
    }

    const userPoolId = process.env.COGNITO_USER_POOL_ID;
    if (!userPoolId) {
      throw new Error('COGNITO_USER_POOL_ID environment variable not set');
    }

    // Create user in Cognito
    const cognitoParams = {
      UserPoolId: userPoolId,
      Username: email,
      TemporaryPassword: password,
      UserAttributes: [
        { Name: 'email', Value: email },
        { Name: 'email_verified', Value: 'true' }
      ],
      MessageAction: 'SUPPRESS' // Don't send automatic welcome email
    };

    let cognitoUser;
    try {
      cognitoUser = await cognito.adminCreateUser(cognitoParams).promise();
    } catch (cognitoError) {
      console.error('[create-user] Cognito error:', cognitoError);
      return {
        statusCode: 400,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: `Failed to create Cognito user: ${cognitoError.message}` })
      };
    }

    const userId = cognitoUser.User.Username;

    // Create profile in database
    try {
      await client.query(
        `INSERT INTO public.profiles (
          id, email, first_name, last_name, title,
          license_number, license_state, is_active, created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())`,
        [
          userId,
          email,
          profile?.first_name || '',
          profile?.last_name || '',
          profile?.title || '',
          profile?.license_number || '',
          profile?.license_state || '',
          true
        ]
      );
    } catch (dbError) {
      // If profile creation fails, delete the Cognito user to keep things consistent
      console.error('[create-user] Database error, rolling back Cognito user:', dbError);
      try {
        await cognito.adminDeleteUser({ UserPoolId: userPoolId, Username: userId }).promise();
      } catch (deleteError) {
        console.error('[create-user] Failed to delete Cognito user during rollback:', deleteError);
      }
      return {
        statusCode: 500,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: `Failed to create user profile: ${dbError.message}` })
      };
    }

    return {
      statusCode: 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        user: {
          id: userId,
          email: email,
          temp_password: password
        }
      })
    };

  } catch (error) {
    console.error('[create-user] Error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: error.message })
    };
  }
};
