/**
 * Universal Delete Database Lambda
 * Handles generic DELETE queries for any table
 * Route: POST /delete/{table}
 */

const { Client } = require('pg');

const getDbConfig = () => ({
  host: process.env.DATABASE_ENDPOINT,
  port: parseInt(process.env.DATABASE_PORT || '5432'),
  database: process.env.DATABASE_NAME,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASSWORD,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 5000,
  query_timeout: 30000,
});

exports.handler = async (event) => {
  console.log('Delete Database Event:', JSON.stringify(event, null, 2));

  const client = new Client(getDbConfig());

  try {
    await client.connect();

    const table = event.pathParameters?.table;
    if (!table) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Table name is required' }),
      };
    }

    const body = JSON.parse(event.body || '{}');
    const { filters = {} } = body;

    // Build WHERE clause from filters
    const conditions = [];
    const values = [];
    let paramIndex = 1;

    for (const [key, value] of Object.entries(filters)) {
      const match = key.match(/^(.+)_(eq|neq|gt|lt)$/);
      if (match) {
        const [, column, operator] = match;

        let parsedValue;
        try {
          parsedValue = JSON.parse(value);
        } catch {
          parsedValue = value;
        }

        switch (operator) {
          case 'eq':
            conditions.push(`${column} = $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'neq':
            conditions.push(`${column} != $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'gt':
            conditions.push(`${column} > $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'lt':
            conditions.push(`${column} < $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
        }
      }
    }

    if (conditions.length === 0) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: 'No filters provided for delete operation',
          message: 'Delete without WHERE clause is not allowed for safety',
        }),
      };
    }

    let query = `DELETE FROM ${table} WHERE ${conditions.join(' AND ')} RETURNING *`;

    console.log('Executing query:', query);
    console.log('With values:', values);

    const result = await client.query(query, values);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      },
      body: JSON.stringify(result.rows),
    };

  } catch (error) {
    console.error('Delete error:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: 'Database delete failed',
        message: error.message,
      }),
    };
  } finally {
    await client.end();
  }
};
