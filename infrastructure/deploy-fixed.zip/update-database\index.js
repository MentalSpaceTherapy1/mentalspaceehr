/**
 * Universal Update Database Lambda
 * Handles generic UPDATE queries for any table
 * Route: PUT /update/{table}
 */

const { Client } = require('pg');

const getDbConfig = () => ({
  host: process.env.DATABASE_ENDPOINT,
  port: parseInt(process.env.DATABASE_PORT || '5432'),
  database: process.env.DATABASE_NAME,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASSWORD,
  ssl: { rejectUnauthorized: false },
  connectionTimeoutMillis: 5000,
  query_timeout: 30000,
});

exports.handler = async (event) => {
  console.log('Update Database Event:', JSON.stringify(event, null, 2));

  const client = new Client(getDbConfig());

  try {
    await client.connect();

    const table = event.pathParameters?.table;
    if (!table) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Table name is required' }),
      };
    }

    const body = JSON.parse(event.body || '{}');
    const { filters = {}, data = {} } = body;

    if (Object.keys(data).length === 0) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'No data provided for update' }),
      };
    }

    // Build SET clause
    const setColumns = Object.keys(data);
    const setClause = setColumns.map((col, index) => `${col} = $${index + 1}`).join(', ');

    // Build WHERE clause from filters
    const conditions = [];
    const values = [...Object.values(data)];
    let paramIndex = setColumns.length + 1;

    for (const [key, value] of Object.entries(filters)) {
      const match = key.match(/^(.+)_(eq|neq|gt|lt)$/);
      if (match) {
        const [, column, operator] = match;

        let parsedValue;
        try {
          parsedValue = JSON.parse(value);
        } catch {
          parsedValue = value;
        }

        switch (operator) {
          case 'eq':
            conditions.push(`${column} = $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'neq':
            conditions.push(`${column} != $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'gt':
            conditions.push(`${column} > $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
          case 'lt':
            conditions.push(`${column} < $${paramIndex}`);
            values.push(parsedValue);
            paramIndex++;
            break;
        }
      }
    }

    let query = `UPDATE ${table} SET ${setClause}`;

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }

    query += ' RETURNING *';

    console.log('Executing query:', query);
    console.log('With values:', values);

    const result = await client.query(query, values);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
      },
      body: JSON.stringify(result.rows),
    };

  } catch (error) {
    console.error('Update error:', error);

    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: 'Database update failed',
        message: error.message,
      }),
    };
  } finally {
    await client.end();
  }
};
