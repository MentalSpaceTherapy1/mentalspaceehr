/**
 * apply-migrations-to-aurora Lambda Function
 * Applies pending database migrations to Aurora PostgreSQL
 */

const { Client } = require('pg');
const AWS = require('aws-sdk');

const secretsManager = new AWS.SecretsManager({ region: process.env.AWS_REGION || 'us-east-1' });

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type, x-amz-date, x-api-key, x-amz-security-token',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
};

let dbClient = null;

async function getDbClient() {
  if (dbClient) return dbClient;

  const secretResponse = await secretsManager.getSecretValue({
    SecretId: process.env.DATABASE_SECRET_ARN
  }).promise();

  const dbCredentials = JSON.parse(secretResponse.SecretString);

  dbClient = new Client({
    host: dbCredentials.host,
    port: dbCredentials.port || 5432,
    database: process.env.DATABASE_NAME,
    user: dbCredentials.username,
    password: dbCredentials.password,
    ssl: { rejectUnauthorized: false }
  });

  await dbClient.connect();
  return dbClient;
}

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.requestContext?.http?.method === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: ''
    };
  }

  try {
    console.log('Starting migration process...');

    // Connect to database
    const client = await getDbClient();
    console.log('✅ Connected to Aurora');

    // Create migrations tracking table if it doesn't exist
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version TEXT PRIMARY KEY,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      );
    `);

    // Get list of already applied migrations
    const appliedResult = await client.query(
      'SELECT version FROM schema_migrations ORDER BY version'
    );
    const appliedMigrations = new Set(appliedResult.rows.map(r => r.version));

    console.log(`Found ${appliedMigrations.size} already applied migrations`);

    // If migrations are provided in the payload, apply them
    const migrations = event.migrations || [];

    if (migrations.length === 0) {
      return {
        statusCode: 200,
        headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: 'ready',
          message: 'No migrations provided. Send migrations in payload to apply them.',
          appliedMigrations: appliedMigrations.size
        })
      };
    }

    console.log(`Received ${migrations.length} migrations to apply`);

    const results = {
      applied: [],
      skipped: [],
      failed: []
    };

    // Apply each migration
    for (const migration of migrations) {
      const migrationName = migration.name.replace('.sql', '');

      if (appliedMigrations.has(migrationName)) {
        console.log(`⏭️  Skipping ${migration.name} (already applied)`);
        results.skipped.push(migration.name);
        continue;
      }

      try {
        console.log(`📦 Applying ${migration.name}...`);

        // Execute the migration SQL
        await client.query(migration.sql);

        // Mark as applied
        await client.query(
          'INSERT INTO schema_migrations (version) VALUES ($1) ON CONFLICT DO NOTHING',
          [migrationName]
        );

        console.log(`✅ Applied ${migration.name}`);
        results.applied.push(migration.name);

      } catch (error) {
        console.error(`❌ Failed to apply ${migration.name}:`, error.message);
        results.failed.push({
          name: migration.name,
          error: error.message
        });
      }
    }

    console.log(`\n📊 Summary: Applied=${results.applied.length}, Skipped=${results.skipped.length}, Failed=${results.failed.length}`);

    return {
      statusCode: results.failed.length > 0 ? 500 : 200,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: results.failed.length > 0 ? 'partial' : 'success',
        summary: {
          total: migrations.length,
          applied: results.applied.length,
          skipped: results.skipped.length,
          failed: results.failed.length
        },
        results: results
      })
    };

  } catch (error) {
    console.error('Lambda error:', error);
    return {
      statusCode: 500,
      headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
